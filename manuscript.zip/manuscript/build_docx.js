// Build the manuscript DOCX from manuscript_source.md, tables.json, verified references and figures.
// Usage: node build_docx.js <out.docx>
const fs = require('fs');
const path = require('path');
const D = require('docx');
const { Document, Packer, Paragraph, TextRun, ImageRun, Table, TableRow, TableCell, WidthType, AlignmentType,
  Header, PageNumber, TabStopType, BorderStyle, ShadingType, LineNumberRestartFormat, PageBreak,
  Math: OMath, MathRun, MathSubScript, MathSuperScript, MathSubSuperScript } = D;

const ROOT = __dirname;
const src = fs.readFileSync(process.argv[3] || path.join(ROOT, 'manuscript_source.md'), 'utf8');
const tables = JSON.parse(fs.readFileSync(process.argv[4] || path.join(ROOT, 'tables.json'), 'utf8'));
const SUPP = !!process.argv[3] && process.argv[3].includes('supp');
const refsDB = JSON.parse(fs.readFileSync(path.join(ROOT, '..', 'manuscript_tools', 'refs_verified.json'), 'utf8'));
const OUT = process.argv[2] || path.join(ROOT, 'manuscript.docx');
const FONT = 'Times New Roman';
const TEXTW = 11906 - 2 * 1440; // A4 text width in DXA

// ---------------- citations: number in order of first appearance
const order = [];
const citeRe = /\[(@[^\]]+)\]/g;
let m;
const body = src.split('%FIGURES')[0];
while ((m = citeRe.exec(body)) !== null) {
  m[1].split(';').map(s => s.trim().replace(/^@/, '')).forEach(k => { if (!order.includes(k)) order.push(k); });
}
// citations inside tables, in order of table markers
(body.match(/\[\[TABLE (S?\d+)\]\]/g) || []).forEach(mk => { const t = tables['Table ' + mk.slice(8, -2)]; if (!t) return;
  const txt = JSON.stringify(t); let q; const re2 = /\[(@[^\]]+)\]/g; while ((q = re2.exec(txt)) !== null) q[1].split(';').map(s => s.trim().replace(/^@/, '')).forEach(k => { if (!order.includes(k)) order.push(k); }); });
const missing = order.filter(k => !refsDB[k]);
if (missing.length) { console.error('Missing references:', missing); process.exit(1); }
function citeNums(keys) {
  const n = [...new Set(keys.map(k => order.indexOf(k) + 1))].sort((a, b) => a - b);
  const parts = []; let i = 0;
  while (i < n.length) {
    let j = i; while (j + 1 < n.length && n[j + 1] === n[j] + 1) j++;
    parts.push(j - i >= 2 ? `${n[i]}–${n[j]}` : (j > i ? `${n[i]},${n[j]}` : `${n[i]}`)); i = j + 1;
  }
  return parts.join(',');
}

// ---------------- inline markup -> TextRuns
function runs(text, base = {}) {
  const out = [];
  // tokens: escaped \*, **bold**, *italic*, ^sup^, ~sub~, [@cite]
  const re = /(\\\*)|(\*\*[^*]+\*\*)|(\*[^*]+\*)|(\^[^^]+\^)|(~[^~]+~)|(\[@[^\]]+\])/g;
  let last = 0, mm;
  const push = (t, o = {}) => { if (t) out.push(new TextRun({ text: t, font: FONT, ...base, ...o })); };
  while ((mm = re.exec(text)) !== null) {
    push(mm[6] ? text.slice(last, mm.index).replace(/\s+$/, '') : text.slice(last, mm.index));
    const t = mm[0];
    if (mm[1]) push('*');
    else if (mm[2]) out.push(...runs(t.slice(2, -2), { ...base, bold: true }));
    else if (mm[3]) out.push(...runs(t.slice(1, -1), { ...base, italics: true }));
    else if (mm[4]) out.push(...runs(t.slice(1, -1), { ...base, superScript: true }));
    else if (mm[5]) out.push(...runs(t.slice(1, -1), { ...base, subScript: true }));
    else if (mm[6]) push(citeNums(t.slice(1, -1).split(';').map(s => s.trim().replace(/^@/, ''))), { superScript: true });
    last = mm.index + t.length;
  }
  push(text.slice(last));
  return out;
}

// ---------------- equations -> formatted, editable text (italic variables, roman labels/functions, true sub/superscripts)
function mathRuns(s, pos = null) {
  const out = []; let buf = '';
  const emit = (t) => {
    if (!t) return;
    // split into letter words, single symbols and other text
    const toks = t.match(/[A-Za-zͰ-Ͽ](?:[A-Za-zͰ-Ͽ̀-ͯ])*|[\s\S]/g) || [];
    for (const tk of toks) {
      const letters = tk.replace(/[̀-ͯ]/g, '');
      const isWord = /^[A-Za-zͰ-Ͽ]+$/.test(letters);
      const roman = !isWord || letters.length >= 3 || letters === 'SB' || /^[ΣΨ]$/.test(letters) && false;
      const italic = isWord && !(letters.length >= 3 || letters === 'SB' || letters === 'Σ');
      out.push(new TextRun({ text: tk, font: FONT, italics: italic, superScript: pos === 'sup', subScript: pos === 'sub' }));
    }
  };
  const readArg = (i) => {
    if (s[i] === '{') { let d = 1, j = i + 1; while (j < s.length && d) { if (s[j] === '{') d++; else if (s[j] === '}') d--; j++; } return [s.slice(i + 1, j - 1), j]; }
    let j = i + 1; while (j < s.length && /[̀-ͯ]/.test(s[j])) j++; return [s.slice(i, j), j];
  };
  let i = 0;
  while (i < s.length) {
    const c = s[i];
    if (c === '_' || c === '^') {
      emit(buf); buf = '';
      let [a1, n1] = readArg(i + 1);
      out.push(...mathRuns(a1, pos || (c === '_' ? 'sub' : 'sup')));
      if ((c === '_' && s[n1] === '^') || (c === '^' && s[n1] === '_')) {
        const [a2, n2] = readArg(n1 + 1); out.push(...mathRuns(a2, pos || (s[n1] === '_' ? 'sub' : 'sup'))); n1 = n2;
      }
      i = n1; continue;
    }
    buf += c; i++;
  }
  emit(buf);
  return out;
}
function equation(line) {
  const mm = line.match(/^\$\$\s*(.*?)\s*\((\d+)\)\s*$/);
  const content = mm[1], num = mm[2];
  const segs = content.split('"');
  const children = [new TextRun({ text: '\t', font: FONT })];
  segs.forEach((sg, i) => {
    if (!sg) return;
    if (i % 2 === 1) children.push(new TextRun({ text: sg, font: FONT }));
    else children.push(...mathRuns(sg));
  });
  children.push(new TextRun({ text: `\t(${num})`, font: FONT }));
  return new Paragraph({ children, tabStops: [{ type: TabStopType.CENTER, position: Math.round(TEXTW / 2) }, { type: TabStopType.RIGHT, position: TEXTW }],
    spacing: { line: 480, before: 120, after: 120 } });
}

// ---------------- helpers
const P = (children, o = {}) => new Paragraph({ children, spacing: { line: 480, after: 240 }, ...o });
const H1 = t => new Paragraph({ children: [new TextRun({ text: t, bold: true, size: 28, font: FONT })], spacing: { before: 360, after: 240, line: 360 }, keepNext: true });
const H2 = t => new Paragraph({ children: runs(t, { bold: true, size: 24 }), spacing: { before: 240, after: 120, line: 360 }, keepNext: true });

function tableBlock(name) {
  const t = tables[name];
  const border = { style: BorderStyle.SINGLE, size: 4, color: '000000' };
  const none = { style: BorderStyle.NONE, size: 0, color: 'FFFFFF' };
  const total = t.widths.reduce((a, b) => a + b, 0);
  const scale = TEXTW / total; const widths = t.widths.map(w => Math.floor(w * scale));
  widths[widths.length - 1] += TEXTW - widths.reduce((a, b) => a + b, 0);
  const cell = (txt, w, hdr, lastRow) => new TableCell({
    width: { size: w, type: WidthType.DXA },
    borders: { top: hdr ? border : none, bottom: (hdr || lastRow) ? border : none, left: none, right: none },
    margins: { top: 40, bottom: 40, left: 60, right: 60 },
    children: [new Paragraph({ children: runs(String(txt), { size: 16, bold: hdr }), spacing: { line: 240 } })] });
  const rows = [new TableRow({ tableHeader: true, children: t.header.map((h, i) => cell(h, widths[i], true, false)) })];
  t.rows.forEach((r, ri) => rows.push(new TableRow({ children: r.map((c, i) => cell(c, widths[i], false, ri === t.rows.length - 1)) })));
  return [
    new Paragraph({ children: [new TextRun({ text: `[${name} near here]`, italics: true, font: FONT, size: 20 })], spacing: { before: 240, after: 120 } }),
    new Paragraph({ children: runs(t.caption, { size: 18 }), spacing: { line: 276, after: 120 }, keepNext: true }),
    new Table({ width: { size: TEXTW, type: WidthType.DXA }, columnWidths: widths, rows }),
    new Paragraph({ children: [], spacing: { after: 240 } })];
}

const captions = {};
src.split('%FIGURES')[1].trim().split('\n').forEach(l => { const k = l.split(' |')[0].trim(); captions[k] = l; });
function figureBlock(n, supp = false) {
  const key = supp ? `Supplementary Figure ${n}` : `Figure ${n}`;
  const file = path.join(ROOT, '..', 'figures', supp ? `FigureS${n}_web.png` : `Figure${n}_web.png`);
  const out = [new Paragraph({ children: [new TextRun({ text: `[${key} near here]`, italics: true, font: FONT, size: 20 })], spacing: { before: 240, after: 120 } })];
  if (fs.existsSync(file)) {
    const buf = fs.readFileSync(file);
    const w = buf.readUInt32BE(16), h = buf.readUInt32BE(20);
    const W = 600; const Hh = Math.round(W * h / w);
    out.push(new Paragraph({ alignment: AlignmentType.CENTER, children: [new ImageRun({ type: 'png', data: buf, transformation: { width: W, height: Hh },
      altText: { title: key, description: captions[key].slice(0, 200), name: key } })] }));
  }
  const cap = captions[key];
  const [lead, ...rest] = cap.split(' | ');
  out.push(new Paragraph({ children: [new TextRun({ text: lead + ' | ', bold: true, font: FONT, size: 18 }), ...runs(rest.join(' | '), { size: 18 })], spacing: { line: 276, after: 240 } }));
  return out;
}

function refEntry(k, i) {
  const r = refsDB[k];
  let au = (r.authors || '').replace(/\.$/, '').split(', ');
  if (au.length > 6 || (au.length === 7 && au[6] === 'et al')) au = au.slice(0, 6).concat(['et al']);
  const auS = au.join(', ').replace(/, et al$/, ', et al.');
  const title = (r.title || '').replace(/<[^>]+>/g, '').replace(/\.?$/, '.');
  const vol = r.volume ? `;${r.volume}` : ''; const iss = r.issue ? `(${r.issue})` : '';
  const pages = r.pages ? `:${r.pages}` : '';
  const doi = r.doi ? ` doi:${r.doi}` : '';
  const txt = `${auS}${auS.endsWith('.') ? '' : '.'} ${title} ${r.journal}. ${r.year}${vol}${iss}${pages}.${doi}`;
  return new Paragraph({ children: [new TextRun({ text: `${i}. `, font: FONT, size: 19 }), new TextRun({ text: txt, font: FONT, size: 19 })],
    spacing: { line: 276, after: 80 }, indent: { left: 400, hanging: 400 } });
}

// ---------------- assemble
const children = [];
const lines = src.split('%FIGURES')[0].split('\n');
let para = [];
const flushPara = () => { if (para.length) { children.push(P(runs(para.join(' ')))); para = []; } };
let inAbstract = false;
for (const raw of lines) {
  const l = raw.trimEnd();
  if (l.startsWith('%TITLE')) { children.push(new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 240, line: 360 }, children: runs(l.slice(7), { bold: true, size: 32 }) })); continue; }
  if (l.startsWith('%AUTHORS')) { children.push(new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 120 }, children: runs(l.slice(9), { size: 24 }) })); continue; }
  if (l.startsWith('%AFFIL')) { children.push(new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 40 }, children: runs(l.slice(7), { size: 20, italics: true }) })); continue; }
  if (l.startsWith('%CORR')) { children.push(new Paragraph({ alignment: AlignmentType.CENTER, spacing: { before: 120, after: 240 }, children: runs(l.slice(6).replace(/^\*/, '\\*'), { size: 20 }) })); continue; }
  if (l.startsWith('%KEYWORDS')) { var KEYWORDS = l.slice(10); continue; }
  if (l.startsWith('%REFERENCES')) { order.forEach((k, i) => children.push(refEntry(k, i + 1))); continue; }
  if (l.startsWith('# ')) {
    flushPara();
    if (inAbstract) { children.push(new Paragraph({ children: [new TextRun({ text: 'Keywords: ', bold: true, font: FONT, size: 20 }), new TextRun({ text: KEYWORDS, font: FONT, size: 20 })], spacing: { after: 240 } })); inAbstract = false; }
    const t = l.slice(2);
    if (t === 'Introduction' || (SUPP && t.startsWith('Supplementary Note'))) children.push(new Paragraph({ children: [new PageBreak()] }));
    children.push(H1(t)); if (t === 'Abstract') inAbstract = true; continue;
  }
  if (l.startsWith('## ')) { flushPara(); children.push(H2(l.slice(3))); continue; }
  if (l.startsWith('$$')) { flushPara(); children.push(equation(l)); continue; }
  let mm;
  if ((mm = l.match(/^\[\[FIGURE (\d+)\]\]$/))) { flushPara(); children.push(...figureBlock(+mm[1])); continue; }
  if ((mm = l.match(/^\[\[TABLE (S?\d+)\]\]$/))) { flushPara(); children.push(...tableBlock(`Table ${mm[1]}`)); continue; }
  if ((mm = l.match(/^\[\[SFIGURE (\d+)\]\]$/))) { flushPara(); children.push(...figureBlock(+mm[1], true)); continue; }
  if (l.trim() === '') { flushPara(); continue; }
  if (inAbstract) { children.push(new Paragraph({ children: runs(l, { size: 22 }), spacing: { line: 360, after: 240 } })); continue; }
  para.push(l);
}
flushPara();
if (!SUPP) { // supplementary figure at the end of the main file
  children.push(new Paragraph({ children: [new PageBreak()] }));
  children.push(H1('Supplementary figure'));
  children.push(...figureBlock(1, true));
}

const doc = new Document({
  creator: '[AUTHOR]', title: 'Splice-isoform chemoaffinity code test',
  styles: { default: { document: { run: { font: FONT, size: 24 } } } },
  sections: [{
    properties: { page: { size: { width: 11906, height: 16838 }, margin: { top: 1440, bottom: 1440, left: 1440, right: 1440 } },
      lineNumbers: { countBy: 1, restart: LineNumberRestartFormat.CONTINUOUS } },
    headers: { default: new Header({ children: [new Paragraph({ alignment: AlignmentType.RIGHT, children: [new TextRun({ children: [PageNumber.CURRENT], font: FONT, size: 20 })] })] }) },
    children }],
});
Packer.toBuffer(doc).then(b => { fs.writeFileSync(OUT, b); console.log('written', OUT, order.length, 'references'); });
