%TITLE Supplementary Information for: A connectome-calibrated test of a splice-isoform chemoaffinity code in mouse visual cortex
%AUTHORS [AUTHOR 1]^1,*^, [AUTHOR 2]^1^, [AUTHOR 3]^2^
%AFFIL ^1^[AFFILIATION 1]; ^2^[AFFILIATION 2]
%CORR *Correspondence: [EMAIL]
%KEYWORDS remote BAM access; BGZF; splice junctions; Patch-seq; reproducibility

# Contents

Supplementary Note 1 (remote, locus-restricted reading of unindexed BAM files); Supplementary Note 2 (identity assignment of Patch-seq alignment files); Supplementary Note 3 (equations in LaTeX); Supplementary Table 1 (curated interactions); Supplementary Table 2 (type-dependent splicing events); Supplementary Figure 1 (Patch-seq identity and replication).

# Supplementary Note 1. Remote, locus-restricted reading of unindexed BAM files

Allen Institute SMART-seq v4 and Patch-seq alignments are distributed as one tar archive per cell, each containing a single coordinate-sorted BAM file without a .bai index. A BAM file is a series of BGZF blocks (gzip members of ≤64 kB uncompressed, each beginning with the bytes 1f 8b 08 04 and carrying its compressed size in the BC extra field) [@Li2009]. Because records are sorted by (reference, position), the key of the first record that starts in each block is a non-decreasing function of the block's compressed offset. The reader (src/remote_bam.py) proceeds as follows. (i) The tar header (512 bytes) gives the member name and size; the BAM header is read from the first blocks to obtain the reference order (RefSeq accessions for GRCm38). (ii) To locate a locus starting at (reference *r*, position *p*), a binary search over compressed offsets requests 32 kB at the midpoint, finds the next BGZF magic sequence, inflates the block (partial inflation is sufficient) and identifies the first complete record by chained validation: a candidate offset is accepted when its block size, reference index, position, read-name length, CIGAR length and sequence length are mutually consistent, the read name is printable and null-terminated, and the next three records validate in the same way. Candidate offsets are pre-filtered with vectorised integer decoding. The search stops when the interval is below 200 kB. (iii) From the last block whose first record precedes the locus, blocks are streamed in chunks that start at 128 kB and double up to 2 MB, records are decoded, and streaming stops at the first record beyond the locus end. Successive loci are searched in file order with the previous start as lower bound. (iv) Only records with MAPQ = 255 (STAR unique mappers) are kept; splice junctions are read from N operations of the CIGAR string and deduplicated per read name to count fragments.

Correctness was tested on fully downloaded, pysam-indexed BAM files for six loci spanning 90–4,030 reads per locus (tests/test_remote_bam.py): read counts and complete junction tables were identical. Transient server errors are handled by exponential back-off (up to eight attempts); a cell that fails after three complete attempts is logged and excluded (1 of 1,544 SMART-seq cells). Across 3,343 cells, the median transfer was 28.0 MB (interquartile range 26.1–29.9 MB) and 512 requests per cell, compared with an average file size of 242 MB (SMART-seq) and 105 MB (Patch-seq).

# Supplementary Note 2. Identity assignment of Patch-seq alignment files

NeMO Patch-seq alignment files are named by analysis-run identifiers (ar_<id>) that are not included in the public metadata, whereas the released count matrix is indexed by transcriptomics sample identifiers. For each alignment file we compared the vector of uniquely mapped read counts for the 52 target genes (log(1 + count), centred and scaled) with the corresponding rows of the released count matrix for all 4,435 cells. Because counting rules differ (locus-start counting of unique reads versus the released counts), correlations of the true match are high but below 1 (median 0.986). An assignment was accepted when the best Pearson correlation was ≥0.85, the margin over the second-best sample was ≥0.05, the best sample belonged to the sequencing tube named in the FASTQ file recorded in the BAM header (an independent criterion) and no other file was assigned to the same sample. Of 1,800 files, 1,697 met all criteria; tube agreement of the best match was 99.9% overall (Supplementary Fig. 1a).

# Supplementary Note 3. Equations

All equations are typeset as editable text in the main manuscript. Their LaTeX source is provided in the repository file manuscript/equations.tex.

# Supplementary Tables

[[TABLE S1]]

[[TABLE S2]]

# Supplementary Figure

[[SFIGURE 1]]

# References

%REFERENCES

%FIGURES
Supplementary Figure 1 | Patch-seq identity assignment and replication. a, Best versus second-best correlation between per-file read counts and released Patch-seq counts; blue, accepted assignments. b, Subclass-level Ψ in dissociated SMART-seq versus Patch-seq interneurons (events with ≥20 fragments in both). c, Subclass mean expression of adhesion and regulator genes in both datasets.
