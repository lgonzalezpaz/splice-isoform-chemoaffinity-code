"""Identify the literature-defined splice inserts among de novo events by sequence.

* Neurexin splice site 4 (SS4): 90-nt cassette exon whose translation contains the canonical 30-residue insert
  (Nrxn1: GNNDNERLAIARQRIPYRLGRVVDEWLLDK; Ichtchenko et al., 1995).
* PTPdelta/sigma/LAR mini-exons: meA (3-, 6- or 9-residue; 9/18/27 nt) and meB (4 residues; 12 nt) cassettes
  in the Ig2-Ig3 region (Yamagata et al., 2015) - assigned by length within Ptprd/Ptprs/Ptprf.
* Teneurin beta-propeller insert (7 residues; 21 nt) abolishing latrophilin binding (Li et al., 2020).
Exon sequences are retrieved from Ensembl REST (GRCm38) and translated for verification.
"""
import os as _os, sys as _sys
_sys.path.insert(0, _os.path.dirname(_os.path.abspath(__file__)) if 'src' in __file__ else _os.path.join(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))), 'src'))
from paths import ROOT, DATA, RES
import sys, os, json, time, requests, numpy as np, pandas as pd
CF = f'{ROOT}/data_ref/exon_sequences_cache.json'
CACHE = json.load(open(CF)) if os.path.exists(CF) else {}
EV, OUT = sys.argv[1], sys.argv[2]
ev = pd.read_csv(EV)
ann = __import__('json').load(open(f'{ROOT}/data_ref/adhesion_annotation_vM25.json'))
CODON = {}
bases = 'TCAG'; aas = 'FFLLSSSSYY**CC*WLLLLPPPPHHQQRRRRIIIMTTTTNNKKSSRRVVVVAAAADDEEGGGG'
k = 0
for a in bases:
    for b in bases:
        for c in bases:
            CODON[a + b + c] = aas[k]; k += 1


def seq(chrom, s, e, strand):
    st = 1 if strand == '+' else -1
    url = f"https://rest.ensembl.org/sequence/region/mouse/{chrom.replace('chr','')}:{s}..{e}:{st}?content-type=text/plain;coord_system_version=GRCm38"
    if url in CACHE: return CACHE[url]
    for _ in range(6):
        try:
            r = requests.get(url, timeout=60)
            if r.status_code == 200:
                CACHE[url] = r.text.strip(); json.dump(CACHE, open(CF, 'w')); return CACHE[url]
        except requests.RequestException:
            pass
        time.sleep(3)
    return ''


def tr(nt):
    return [''.join(CODON.get(nt[i:i + 3], 'X') for i in range(f, len(nt) - 2, 3)) for f in range(3)]


SS4 = 'NNDNERLAIARQRIPYRLGRVVDEWLLDK'
rows = []
cand = ev[(ev.type == 'cassette') & ev.gene.isin(['Nrxn1', 'Nrxn2', 'Nrxn3', 'Ptprd', 'Ptprs', 'Ptprf', 'Tenm1', 'Tenm2', 'Tenm3', 'Tenm4', 'Nlgn1', 'Nlgn2', 'Nlgn3'])]
cand = cand[(cand.gene.str.startswith('Nrxn') & (cand.length == 90)) | (cand.gene.isin(['Ptprd', 'Ptprs', 'Ptprf']) & cand.length.isin([9, 12, 15, 18, 27]))
            | (cand.gene.str.startswith('Tenm') & (cand.length == 21)) | cand.gene.str.startswith('Nlgn')]
for _, r in cand.drop_duplicates('event').iterrows():
    s, e = map(int, r.exon.split('@')[0].split('-')); g = ann['genes'][r.gene]
    nt = seq(g['chrom'], s, e, g['strand']); peps = tr(nt)
    best = max(peps, key=lambda p: sum(x == y for x, y in zip(p, SS4[:len(p)])) if len(p) >= 25 else 0)
    ss4_id = max((sum(a == b for a, b in zip(p[i:], SS4)) / len(SS4) for p in peps for i in range(0, 3)), default=0)
    rule = None
    if r.gene.startswith('Nrxn') and r.length == 90 and ss4_id >= 0.45 and any('DNERL' in p for p in peps): rule = 'SS4'
    if r.gene in ('Ptprd', 'Ptprs', 'Ptprf') and r.length == 12: rule = 'MEB'
    if r.gene in ('Ptprd', 'Ptprs', 'Ptprf') and r.length in (9, 18, 27): rule = 'MEA'
    if r.gene.startswith('Tenm') and r.length == 21: rule = 'TENM'
    rows.append(dict(event=r.event, gene=r.gene, length=r.length, nt=nt, aa_frames='|'.join(peps), ss4_identity=round(ss4_id, 2), rule=rule,
                     q=r.get('q'), psi_range=r.psi_range, n_total=r.n_inc + r.n_exc))
    time.sleep(0.2)
lab = pd.DataFrame(rows)
# meA and meB mini-exons are juxtaposed (Ig2 / Ig2-Ig3 linker): keep only mini-exons within 10 kb of the opposite class
lab['start'] = lab.event.str.split(':').str[2].str.split('@').str[0].str.split('-').str[0].astype(int)
for i, r in lab[lab.rule.isin(['MEA', 'MEB'])].iterrows():
    other = lab[(lab.gene == r.gene) & lab.rule.isin(['MEA', 'MEB']) & (lab.rule != r.rule)]
    if len(other) == 0 or (other.start - r.start).abs().min() > 10000:
        lab.loc[i, 'rule'] = None
lab.to_csv(OUT.replace('.csv', '_all_candidates.csv'), index=False)
key = lab[lab.rule.notna()].copy()
# keep the best-supported event per gene x rule x exon (largest informative read count)
key['exon'] = key.event.str.split(':').str[2].str.split('@').str[0]
key = key.sort_values('n_total', ascending=False).drop_duplicates(['gene', 'rule', 'exon'])
key[['rule', 'gene', 'event', 'length', 'ss4_identity', 'n_total', 'q', 'psi_range', 'aa_frames']].to_csv(OUT, index=False)
print(key[['rule', 'gene', 'event', 'length', 'ss4_identity', 'n_total', 'q', 'psi_range']].to_string())
