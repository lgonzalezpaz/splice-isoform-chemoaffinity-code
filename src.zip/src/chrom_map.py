"""UCSC mm10 chromosome names -> RefSeq GRCm38.p6 accessions used by Allen STAR references."""
UCSC2REFSEQ = {**{f"chr{i}": f"NC_0000{66+i}.6" for i in range(1, 20)},
               "chrX": "NC_000086.7", "chrY": "NC_000087.7", "chrM": "NC_005089.1"}
UCSC2REFSEQ["chr2"] = "NC_000068.7"
