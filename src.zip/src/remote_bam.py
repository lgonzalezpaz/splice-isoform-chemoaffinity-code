"""Region-restricted reading of coordinate-sorted, *unindexed* BAM files served over HTTP.

Allen Institute SMART-seq v4 / Patch-seq alignments are distributed on NeMO as one tar
archive per cell containing a single coordinate-sorted BAM and no .bai index. Downloading
whole files (100-250 MB per cell) is unnecessary when only ~40 loci are needed. Because a
sorted BAM is a monotonic sequence of BGZF blocks, the compressed offset at which a given
genomic coordinate begins can be found by binary search with HTTP range requests; the
locus is then streamed until the first record beyond its end.

The extractor returns, for every read with MAPQ == 255 (STAR unique mappers):
  * splice junctions (intron start, intron end; 1-based inclusive genomic coordinates)
  * aligned blocks, used for exon/gene read counting.
Correctness is verified against pysam on fully downloaded BAMs (tests/test_remote_bam.py).
"""
from __future__ import annotations
import struct, zlib, bisect, time
import numpy as np
import requests

MAGIC = b"\x1f\x8b\x08\x04"
REC = struct.Struct("<iiBBHHHiiii")  # refID,pos,l_read_name,mapq,bin,n_cigar,flag,l_seq,next_refID,next_pos,tlen


class RemoteBAM:
    def __init__(self, url: str, session: requests.Session | None = None, probe: int = 40000):
        self.url = url
        self.s = session or requests.Session()
        self.probe_size = probe
        self.nreq = 0
        self.nbytes = 0
        h = self._get(0, 511)
        name = h[:100].rstrip(b"\0").decode()
        if name.endswith(".bam") and h[257:262] == b"ustar":
            self.base = 512
            self.size = int(h[124:136].rstrip(b"\0 ") or b"0", 8)
        else:  # bare BAM
            self.base = 0
            r = self.s.head(url, timeout=60)
            self.size = int(r.headers["Content-Length"])
        self._read_header()
        self._cache: dict[int, tuple] = {}

    # ------------------------------------------------------------------ IO
    def _get(self, a: int, b: int) -> bytes:
        for attempt in range(8):
            if attempt:
                time.sleep(min(30, 2 ** attempt))
            try:
                r = self.s.get(self.url, headers={"Range": f"bytes={a}-{b}"}, timeout=120)
                if r.status_code in (200, 206):
                    self.nreq += 1
                    self.nbytes += len(r.content)
                    return r.content
            except requests.RequestException:
                pass
        raise IOError(f"range request failed {self.url} {a}-{b}")

    @staticmethod
    def _blocks(buf: bytes, p: int = 0):
        """Yield (offset, uncompressed) for complete BGZF blocks in buf starting at p."""
        n = len(buf)
        while p + 18 <= n and buf[p:p + 4] == MAGIC:
            bsize = struct.unpack_from("<H", buf, p + 16)[0] + 1
            if p + bsize > n:
                return
            yield p, zlib.decompress(buf[p + 18:p + bsize - 8], -15), bsize
            p += bsize

    def _read_header(self):
        buf = self._get(self.base, self.base + 400000)
        u = b"".join(x[1] for x in self._blocks(buf))
        assert u[:4] == b"BAM\1", "not a BAM"
        lt = struct.unpack_from("<i", u, 4)[0]
        p = 8 + lt
        nref = struct.unpack_from("<i", u, p)[0]; p += 4
        self.refs, self.reflen = [], []
        for _ in range(nref):
            ln = struct.unpack_from("<i", u, p)[0]; p += 4
            self.refs.append(u[p:p + ln - 1].decode()); p += ln
            self.reflen.append(struct.unpack_from("<i", u, p)[0]); p += 4
        self.header_text = u[8:8 + lt].decode(errors="replace")
        self.rid = {r: i for i, r in enumerate(self.refs)}

    # ------------------------------------------------------- record parsing
    def _valid_at(self, u: bytes, p: int) -> int | None:
        """Return end offset of a plausible record at p, else None."""
        if p + 36 > len(u):
            return None
        bs = struct.unpack_from("<i", u, p)[0]
        if bs < 32 or bs > 100000:
            return None
        refid, pos, lrn, mapq, bin_, ncig, flag, lseq, nref, npos, tlen = REC.unpack_from(u, p + 4)
        if not (-1 <= refid < len(self.refs)) or pos < -1 or lrn < 2 or lseq < 0 or lseq > 10000:
            return None
        if refid >= 0 and pos > self.reflen[refid]:
            return None
        if 32 + lrn + 4 * ncig + (lseq + 1) // 2 + lseq > bs:
            return None
        q = p + 36
        if q + lrn > len(u):
            return None
        name = u[q:q + lrn]
        if name[-1] != 0 or any(c < 33 or c > 126 for c in name[:-1]):
            return None
        return p + 4 + bs

    def _first_record(self, u: bytes) -> int | None:
        """Find a record boundary in decompressed data u by chained validation (numpy-prefiltered)."""
        n = min(len(u), 70000)
        if n < 40:
            return None
        a = np.frombuffer(u, dtype=np.uint8, count=min(len(u), n + 16)).astype(np.int64)
        m = n - 12
        i32 = lambda o: (a[o:o + m] | (a[o + 1:o + 1 + m] << 8) | (a[o + 2:o + 2 + m] << 16) | (a[o + 3:o + 3 + m] << 24))
        bs = i32(0); rid = i32(4); pos = i32(8)
        rid = np.where(rid >= 2 ** 31, rid - 2 ** 32, rid); pos = np.where(pos >= 2 ** 31, pos - 2 ** 32, pos)
        cand = np.where((bs >= 32) & (bs <= 100000) & (rid >= -1) & (rid < len(self.refs)) & (pos >= -1))[0]
        for p in cand.tolist():
            e1 = self._valid_at(u, p)
            if e1 is None:
                continue
            ok = True; q = e1
            for _ in range(3):
                if q >= len(u) - 36:
                    break
                e = self._valid_at(u, q)
                if e is None:
                    ok = False; break
                q = e
            if ok:
                return p
        return None

    def _probe(self, coff: int):
        """Key (refid,pos) of the first record starting in the first block at/after compressed offset coff."""
        if coff in self._cache:
            return self._cache[coff]
        a = self.base + coff
        buf = self._get(a, min(a + self.probe_size, self.base + self.size - 1))
        p = buf.find(MAGIC + b"\x00\x00\x00\x00\x00\xff\x06\x00BC\x02\x00")
        if p < 0:
            p = buf.find(MAGIC)
        if p < 0:
            res = None
        else:
            d = zlib.decompressobj(-15)
            u = d.decompress(buf[p + 18:])
            # records starting inside this block: the first boundary may straddle; use chained validation
            r = self._first_record(u)
            if r is None:
                res = None
            else:
                refid, pos = struct.unpack_from("<ii", u, r + 4)
                key = (refid if refid >= 0 else 1 << 30, pos)
                res = (coff + p, key)
        self._cache[coff] = res
        return res

    def find_start(self, rid: int, start: int, lo: int = 0) -> int:
        """Largest compressed block offset whose first record key < (rid,start)."""
        hi = self.size - 1
        target = (rid, start)
        best = lo
        while hi - lo > 200000:
            mid = (lo + hi) // 2
            pr = self._probe(mid)
            if pr is None:
                hi = mid; continue
            boff, key = pr
            if key < target:
                best = max(best, boff); lo = mid
            else:
                hi = mid
        return best

    def fetch(self, chrom: str, start: int, end: int, chunk: int = 1 << 17, lo: int = 0):
        """Yield (pos1, cigar_ops, flag, qname) for MAPQ==255 records with refid==chrom and start<=pos<=end.
        pos1 is 1-based leftmost position."""
        rid = self.rid[chrom]
        coff = self.find_start(rid, start - 1, lo)
        self.last_start = coff
        carry = b""
        d_off = coff
        done = False
        while not done and d_off < self.size:
            a = self.base + d_off
            buf = self._get(a, min(a + chunk, self.base + self.size - 1))
            consumed = 0
            for p, u, bs in self._blocks(buf):
                consumed = p + bs
                data = carry + u
                q = 0
                if carry == b"" and d_off == coff and p == 0:
                    r = self._first_record(data)
                    q = r if r is not None else len(data)
                n = len(data)
                while q + 4 <= n:
                    bsz = struct.unpack_from("<i", data, q)[0]
                    if q + 4 + bsz > n:
                        break
                    refid, pos, lrn, mapq, bin_, ncig, flag, lseq = struct.unpack_from("<iiBBHHHi", data, q + 4)
                    if refid > rid or refid < 0 or (refid == rid and pos > end - 1):
                        done = True; break
                    if refid == rid and pos >= start - 1 and mapq == 255:
                        c0 = q + 36 + lrn
                        cig = struct.unpack_from(f"<{ncig}I", data, c0)
                        qname = data[q + 36:q + 36 + lrn - 1]
                        yield pos + 1, cig, flag, qname
                    q += 4 + bsz
                carry = data[q:]
                if done:
                    break
            if consumed == 0:
                chunk *= 2
                if chunk > 1 << 23:
                    raise IOError("no complete BGZF block in chunk")
                continue
            d_off += consumed
            chunk = min(chunk * 2, 1 << 21)


def blocks_and_junctions(pos1: int, cig):
    """Convert CIGAR to aligned blocks [(s,e)] and junctions [(intron_start,intron_end)] (1-based, inclusive)."""
    blocks, juncs = [], []
    r = pos1
    bs = r
    for c in cig:
        op, ln = c & 0xF, c >> 4
        if op in (0, 7, 8):  # M = X
            r += ln
        elif op == 2:  # D
            r += ln
        elif op == 3:  # N
            blocks.append((bs, r - 1)); juncs.append((r, r + ln - 1)); r += ln; bs = r
    blocks.append((bs, r - 1))
    return blocks, juncs
