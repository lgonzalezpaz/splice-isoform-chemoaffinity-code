#!/usr/bin/env bash
# Download all public inputs (approx. 3.5 GB). Requires curl. DATA_DIR defaults to ./data.
set -euo pipefail
D=${DATA_DIR:-$(cd "$(dirname "$0")/.." && pwd)/data}
mkdir -p "$D"/{microns,tasic,patchseq,ref,splicing}
G=https://storage.googleapis.com/mat_dbs/public/minnie65_phase3_v1/v1412
for t in aibs_metamodel_celltypes_v661_merged nucleus_detection_v0_merged proofreading_status_and_strategy_merged aibs_cell_info_merged; do
  curl -sSfL -o "$D/microns/$t.csv.gz" "$G/$t.csv.gz"; curl -sSfL -o "$D/microns/${t}_header.csv" "$G/${t}_header.csv"
done
curl -sSfL -o "$D/microns/connections_with_nuclei_header.csv" "$G/connections_with_nuclei_header.csv"
[ -s "$D/microns/connections_with_nuclei.csv.gz" ] || curl -sSfL -o "$D/microns/connections_with_nuclei.csv.gz" "$G/connections_with_nuclei.csv.gz"   # 2.9 GB
GEO=https://ftp.ncbi.nlm.nih.gov/geo/series/GSE115nnn/GSE115746/suppl
for f in GSE115746_complete_metadata_28706-cells.csv.gz GSE115746_cells_exon_counts.csv.gz; do
  [ -s "$D/tasic/$f" ] || curl -sSfL -o "$D/tasic/$f" "$GEO/$f"; done
N=https://data.nemoarchive.org/biccn/grant/u19_zeng/zeng/transcriptome/scell/SSv4/mouse/processed
curl -sSfL -o "$D/tasic/final_ctx-hip_SMART_master-2024-12-10.csv" "$N/YaoHippo2020/final_ctx-hip_SMART_master-2024-12-10.csv"
curl -sSfL "$N/align/VISp/" | grep -oE 'href="[^"]+\.bam\.tar"' | sed 's/href="//;s/"$//' > "$D/tasic/visp_bam_list.txt"
P=https://data.nemoarchive.org/other/AIBS/AIBS_patchseq/transcriptome/scell/SMARTseq/processed
(cd "$D/patchseq" && curl -sSfL -O "$P/analysis/20200611/20200625_patchseq_metadata_mouse.csv.tar" && tar xf 20200625_patchseq_metadata_mouse.csv.tar \
  && { [ -s 20200513_Mouse_PatchSeq_Release_count.v2.csv.tar ] || curl -sSfL -O "$P/analysis/20200611/20200513_Mouse_PatchSeq_Release_count.v2.csv.tar"; } \
  && tar xf 20200513_Mouse_PatchSeq_Release_count.v2.csv.tar)
curl -sSfL "$P/align/20200611/" | grep -oE 'ar_[0-9]+_STAR_Aligned.sortedByCoord.out.bam.tar' | sort -u > "$D/patchseq/ps_bam_list.txt"
[ -s "$D/ref/gencode.vM25.annotation.gtf.gz" ] || curl -sSfL -o "$D/ref/gencode.vM25.annotation.gtf.gz" https://ftp.ebi.ac.uk/pub/databases/gencode/Gencode_mouse/release_M25/gencode.vM25.annotation.gtf.gz
echo "downloads complete: $D"
