"""Select SMART-seq v4 cells (Tasic et al. 2018, VISp) and Patch-seq cells (Gouwens et al. 2020) for splicing extraction."""
import os as _os, sys as _sys
_sys.path.insert(0, _os.path.dirname(_os.path.abspath(__file__)) if 'src' in __file__ else _os.path.join(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))), 'src'))
from paths import ROOT, DATA, RES
import pandas as pd, numpy as np, re, sys, subprocess
D = f'{DATA}'
rng = np.random.default_rng(20261022)
m = pd.read_csv(f'{D}/tasic/GSE115746_complete_metadata_28706-cells.csv.gz')
mm = pd.read_csv(f'{D}/tasic/final_ctx-hip_SMART_master-2024-12-10.csv', encoding='utf-8-sig', usecols=['sample_name', 'exp_component_name'])
d = m.merge(mm, on='sample_name', how='inner')
SUB = ['L2/3 IT', 'L4', 'L5 IT', 'L5 PT', 'NP', 'L6 IT', 'L6 CT', 'L6b', 'Pvalb', 'Sst', 'Vip', 'Lamp5', 'Sncg']
have = set(l.strip().replace('.bam.tar','') for l in open(f'{D}/tasic/visp_bam_list.txt'))
v = d[d.exp_component_name.isin(have) & d.source_name.str.contains('VISp', na=False) & (d.sequencing_qc_pass_fail == 'Pass') & d.cell_subclass.isin(SUB)]
N = int(sys.argv[1]) if len(sys.argv) > 1 else 120
sel = pd.concat([x.sample(min(N, len(x)), random_state=1) for _, x in v.groupby('cell_subclass')])
base = 'https://data.nemoarchive.org/biccn/grant/u19_zeng/zeng/transcriptome/scell/SSv4/mouse/processed/align/VISp/'
sel = sel.assign(url=base + sel.exp_component_name + '.bam.tar')
sel[['sample_name', 'url']].rename(columns={'sample_name': 'cell_id'}).to_csv(f'{D}/tasic/cells_selected.tsv', sep='\t', index=False)
sel[['sample_name', 'exp_component_name', 'cell_subclass', 'cell_cluster', 'dissected_layer', 'donor_id']].to_csv(f'{D}/tasic/cells_selected_meta.csv', index=False)
print(sel.cell_subclass.value_counts())

# Patch-seq alignment files: random sample of 1,800 of 4,435 (seed 7)
l = [x.strip() for x in open(f'{D}/patchseq/ps_bam_list.txt') if x.strip()]
selp = np.random.default_rng(7).choice(l, 1800, replace=False)
basep = 'https://data.nemoarchive.org/other/AIBS/AIBS_patchseq/transcriptome/scell/SMARTseq/processed/align/20200611/'
pd.DataFrame({'cell_id': [s_.split('_STAR')[0] for s_ in selp], 'url': [basep + s_ for s_ in selp]}).to_csv(f'{D}/patchseq/ps_cells_selected.tsv', sep='\t', index=False)
