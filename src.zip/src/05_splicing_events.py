"""De novo detection and type-level quantification of alternative splicing events in adhesion genes.

Input: per-cell junction counts (02_extract_splicing.py) + cell metadata (subclass).
Events: (i) cassette exons supported by two inclusion junctions and one skipping junction;
        (ii) alternative 5'/3' splice sites (junction pairs sharing one end, other ends <= 60 nt apart).
PSI per subclass from pseudobulk counts; 95% CIs by cell bootstrap; type dependence tested by
quasi-binomial GLM (cell-level counts; dispersion-corrected F test) with Benjamini-Hochberg FDR.
"""
import sys, json, collections, numpy as np, pandas as pd
from statsmodels.stats.multitest import multipletests
JS, META, OUT = sys.argv[1], sys.argv[2], sys.argv[3]
ID_COL = sys.argv[4] if len(sys.argv) > 4 else 'cell_id'
MIN_TOTAL = 30
rng = np.random.default_rng(3)
meta = pd.read_csv(META)
lab = dict(zip(meta[ID_COL], meta['subclass']))
cells, J, G, PC = [], collections.defaultdict(dict), {}, {}
for l in open(JS):
    r = json.loads(l)
    if r['cell_id'] not in lab: continue
    cells.append(r['cell_id'])
    for g, d in r['junctions'].items():
        for k, v in d.items():
            J[(g, k)][r['cell_id']] = v
    G[r['cell_id']] = r['genes']; PC[r['cell_id']] = r.get('pcdh', {})
cells = np.array(cells); sub = np.array([lab[c] for c in cells])
print(len(cells), 'cells', pd.Series(sub).value_counts().to_dict())
cidx = {c: i for i, c in enumerate(cells)}
jmat = {}
for key, d in J.items():
    v = np.zeros(len(cells), np.int32)
    for c, n in d.items(): v[cidx[c]] = n
    jmat[key] = v
tot = {k: v.sum() for k, v in jmat.items()}
by_gene = collections.defaultdict(list)
for (g, k), t in tot.items():
    if t >= 3:
        a, b = map(int, k.split('-')); by_gene[g].append((a, b))
events = []
for g, js in by_gene.items():
    S = set(js)
    starts = collections.defaultdict(list); ends = collections.defaultdict(list)
    for a, b in js: starts[a].append(b); ends[b].append(a)
    # cassette: skip (a,d); inclusion (a,b1) and (c1,d) with b1 < c1
    for a, d in js:
        for b1 in starts[a]:
            if b1 >= d: continue
            for c1 in ends[d]:
                if c1 <= b1 + 1: continue
                if (a, b1) in S and (c1, d) in S:
                    exs, exe = b1 + 1, c1 - 1
                    if exe - exs + 1 > 500: continue
                    events.append(dict(gene=g, type='cassette', exon=f'{exs}-{exe}', length=exe - exs + 1,
                                       inc=[f'{a}-{b1}', f'{c1}-{d}'], exc=[f'{a}-{d}']))
    # alternative donor/acceptor sites
    for a, bl in starts.items():
        bl = sorted(set(bl))
        for i in range(len(bl)):
            for j in range(i + 1, len(bl)):
                if bl[j] - bl[i] <= 60:
                    events.append(dict(gene=g, type='alt_end', exon=f'{a}:{bl[i]}|{bl[j]}', length=bl[j] - bl[i],
                                       inc=[f'{a}-{bl[j]}'], exc=[f'{a}-{bl[i]}']))
    for b, al in ends.items():
        al = sorted(set(al))
        for i in range(len(al)):
            for j in range(i + 1, len(al)):
                if al[j] - al[i] <= 60:
                    events.append(dict(gene=g, type='alt_start', exon=f'{al[i]}|{al[j]}:{b}', length=al[j] - al[i],
                                       inc=[f'{al[i]}-{b}'], exc=[f'{al[j]}-{b}']))
def het_stat(I, E):
    # pseudobulk chi-square-like statistic: sum_s n_s (psi_s - psi)^2 / (psi (1-psi))
    n = I + E; psi = I.sum(-1, keepdims=True) / n.sum(-1, keepdims=True)
    ps = np.divide(I, n, out=np.zeros_like(I), where=n > 0)
    return (n * (ps - psi) ** 2).sum(-1) / np.clip(psi[..., 0] * (1 - psi[..., 0]), 1e-9, None)


def perm_test(inc, exc, labels, B=2000):
    u, codes = np.unique(labels, return_inverse=True)
    oh = np.eye(len(u))[codes]
    obs = het_stat((inc @ oh)[None], (exc @ oh)[None])[0]
    P = np.array([rng.permutation(codes) for _ in range(B)])
    Ip = np.stack([np.bincount(p, weights=inc, minlength=len(u)) for p in P])
    Ep = np.stack([np.bincount(p, weights=exc, minlength=len(u)) for p in P])
    null = het_stat(Ip, Ep)
    return obs, (1 + (null >= obs).sum()) / (B + 1)


SUBS = [s for s in ['L2/3 IT', 'L4', 'L5 IT', 'L5 PT', 'NP', 'L6 IT', 'L6 CT', 'L6b', 'Pvalb', 'Sst', 'Vip', 'Lamp5', 'Sncg'] if (sub == s).any()]
rows = []; cell_counts = {}
for e in events:
    inc = sum(jmat[(e['gene'], k)] for k in e['inc']) / len(e['inc'])
    exc = sum(jmat[(e['gene'], k)] for k in e['exc'])
    if inc.sum() + exc.sum() < MIN_TOTAL: continue
    eid = f"{e['gene']}:{e['type']}:{e['exon']}" + (f"@{e['exc'][0]}" if e['type'] == 'cassette' else '')
    cell_counts[eid] = (inc, exc)
    r = dict(event=eid, gene=e['gene'], type=e['type'], exon=e['exon'], length=e['length'], n_inc=float(inc.sum()), n_exc=float(exc.sum()))
    for s in SUBS:
        m = sub == s
        I, E = inc[m].sum(), exc[m].sum()
        r[f'psi|{s}'] = I / (I + E) if I + E > 0 else np.nan
        r[f'n|{s}'] = I + E
        # cell bootstrap CI
        idx = np.where(m)[0]
        if I + E >= 5:
            bs = []
            for _ in range(300):
                k = rng.choice(idx, len(idx)); a, b = inc[k].sum(), exc[k].sum()
                bs.append(a / (a + b) if a + b > 0 else np.nan)
            r[f'lo|{s}'], r[f'hi|{s}'] = np.nanpercentile(bs, [2.5, 97.5])
    # cell-label permutation test of between-subclass heterogeneity (robust to overdispersion and sparsity)
    m = (inc + exc) > 0
    r['n_cells_inf'] = int(m.sum())
    if m.sum() >= 20 and len(set(sub[m])) >= 3:
        r['stat'], r['p'] = perm_test(inc[m], exc[m], sub[m])
    rows.append(r)
df = pd.DataFrame(rows)
# keep genuinely alternative events: 0.05 < PSI < 0.95 in at least one subclass with >= 20 informative reads
psi_cols = [f'psi|{s}' for s in SUBS]; n_cols = [f'n|{s}' for s in SUBS]
alt = np.zeros(len(df), bool)
for pc, nc in zip(psi_cols, n_cols):
    alt |= (df[nc] >= 20) & (df[pc] > 0.05) & (df[pc] < 0.95)
df['alternative'] = alt
ok = df.p.notna() & df.alternative
df.loc[ok, 'q'] = multipletests(df.loc[ok, 'p'], method='fdr_bh')[1]
psi = df[[f'psi|{s}' for s in SUBS]].to_numpy()
df['psi_range'] = np.nanmax(psi, 1) - np.nanmin(psi, 1)
df = df.sort_values('p')
df.to_csv(OUT, index=False)
np.save(OUT.replace('.csv', '_cellcounts.npy'), {'cells': cells, 'sub': sub, 'counts': cell_counts}, allow_pickle=True)
# gene reads & Pcdh per cell
pd.DataFrame(G).T.assign(subclass=lambda x: [lab[c] for c in x.index]).to_csv(OUT.replace('.csv', '_genereads.csv'))
pd.DataFrame(PC).T.fillna(0).assign(subclass=lambda x: [lab[c] for c in x.index]).to_csv(OUT.replace('.csv', '_pcdh.csv'))
print(df.type.value_counts().to_dict(), 'events;', int(df.alternative.sum()), 'alternative;', int((df.q < 0.05).sum()), 'FDR<0.05')
print(df[df.alternative][['event', 'length', 'n_inc', 'n_exc', 'psi_range', 'q']].head(40).to_string())
