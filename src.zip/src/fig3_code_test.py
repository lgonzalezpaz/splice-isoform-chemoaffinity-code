"""Figure 3: testing an isoform-resolved adhesion code against geometry-corrected connectivity."""
import os as _os, sys as _sys
_sys.path.insert(0, _os.path.dirname(_os.path.abspath(__file__)) if 'src' in __file__ else _os.path.join(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))), 'src'))
from paths import ROOT, DATA, RES
import numpy as np, pandas as pd, matplotlib.pyplot as plt, os, sys, json
from scipy import stats
sys.path.insert(0, os.path.dirname(__file__))
from fig_style import *
setup()
R = f'{RES}'; C = f'{R}/code'; FD = f'{ROOT}/figures'
S = json.load(open(f'{C}/summary.json'))
t1 = pd.read_csv(f'{C}/T1_per_interaction.csv')
tp = pd.read_csv(f'{R}/microns/type_pair_stats.csv')
I = tp.pivot(index='pre_type', columns='post_type', values='interaction').reindex(index=TYPES, columns=TYPES).to_numpy()
y = I.ravel()
fig = plt.figure(figsize=(7.4, 6.6))
gs = fig.add_gridspec(2, 3, hspace=0.5, wspace=0.6, width_ratios=[1.15, 1, 1])

ax = fig.add_subplot(gs[:, 0]); panel(ax, 'a', x=-0.55, y=1.01)
p = t1.pivot(index='id', columns='version', values='rho'); q = t1.pivot(index='id', columns='version', values='q')
rule = t1.drop_duplicates('id').set_index('id').rule
p = p.sort_values('iso'); yy = np.arange(len(p))
for i, k in enumerate(p.index):
    ax.plot([p.loc[k, 'blind'], p.loc[k, 'iso']], [i, i], color=GRID, lw=1.2, zorder=0)
ax.scatter(p['blind'], yy, s=12, facecolor='white', edgecolor=CAT[0], lw=0.8, label='gene-level', zorder=2)
ax.scatter(p['iso'], yy, s=12, color=CAT[1], lw=0, label='isoform-gated', zorder=3)
for i, k in enumerate(p.index):
    if q.loc[k, 'iso'] < 0.1 or q.loc[k, 'blind'] < 0.05:
        ax.text(0.47, i, '*' if min(q.loc[k, 'iso'], q.loc[k, 'blind']) < 0.05 else '·', va='center', fontsize=8, color=INK)
labels = [k + (' †' if rule[k] != 'none' else '') for k in p.index]
ax.set_yticks(yy); ax.set_yticklabels(labels, fontsize=5.4); ax.axvline(0, color=INK2, lw=0.6)
ax.set_xlabel('Spearman ρ with interaction term'); ax.set_xlim(-0.5, 0.5)
ax.legend(frameon=False, loc='lower right', fontsize=5.5, handletextpad=0.1)
ax.set_title('Single interactions', loc='left')

ax = fig.add_subplot(gs[0, 1]); panel(ax, 'b', x=-0.32)
pred = np.load(f'{C}/T2_pred_pair_blind.npy')
cls = np.array([0] * 7 + [1] * 4); A = np.repeat(cls, 11); B = np.tile(cls, 11)
names = {(0, 0): 'E→E', (0, 1): 'E→I', (1, 0): 'I→E', (1, 1): 'I→I'}
for k_, (a, b) in enumerate(names):
    m = (A == a) & (B == b)
    ax.scatter(pred[m], y[m], s=9, color=CAT[k_], lw=0, label=names[(a, b)])
ax.set_xlabel('Cross-validated prediction'); ax.set_ylabel('Observed interaction')
ax.legend(frameon=False, fontsize=5.5, loc='upper left', handletextpad=0.1, ncol=2, columnspacing=0.5)
ax.text(0.97, 0.04, f"LOO ρ = {S['T2']['pair_blind']:.2f}", transform=ax.transAxes, ha='right', fontsize=6)
ax.set_title('Bilinear model (gene-level)', loc='left')

ax = fig.add_subplot(gs[0, 2]); panel(ax, 'c', x=-0.32)
rnd = np.load(f'{C}/T2_random_gene_cv.npy'); prm = np.load(f'{C}/T2_perm_cv.npy')
ax.hist(prm, bins=30, color='#d9d9d9', density=True, label='type-label permutation')
ax.hist(rnd, bins=30, histtype='step', color=INK2, lw=1, density=True, label='random gene pairs')
for v, c, nm in [(S['T2']['pair_iso'], CAT[1], 'isoform-gated'), (S['T2']['pair_blind'], CAT[0], 'gene-level')]:
    ax.axvline(v, color=c, lw=1.4, label=nm)
ax.set_ylim(0, ax.get_ylim()[1] * 1.45)
ax.set_xlabel('Cross-validated ρ'); ax.set_ylabel('Density'); ax.legend(frameon=False, fontsize=5.2, loc='upper left')
ax.set_title('Curated vs null gene sets', loc='left')

ax = fig.add_subplot(gs[1, 1]); panel(ax, 'd', x=-0.32)
dn = np.load(f'{C}/T3_psi_perm_delta.npy')
ax.hist(dn, bins=30, color='#d9d9d9', density=True); ax.set_ylim(0, ax.get_ylim()[1] * 1.5)
ax.axvline(S['T3']['delta_cv_rho'], color=CAT[1], lw=1.4)
ax.set_xlabel('Δρ (isoform-gated − gene-level)'); ax.set_ylabel('Density')
ax.text(0.03, 0.97, f"observed Δρ = {S['T3']['delta_cv_rho']:.2f}\n95% CI {S['T3']['delta_ci95'][0]:.2f} to {S['T3']['delta_ci95'][1]:.2f}\nP$_{{PSI-perm}}$ = {S['T3']['p_psi_perm']:.2f}",
        transform=ax.transAxes, va='top', fontsize=5.8)
ax.set_title('Isoform information', loc='left')

ax = fig.add_subplot(gs[1, 2]); panel(ax, 'e', x=-0.32)
pw = S['T8_power']; xs = sorted(float(k) for k in pw)
ax.plot(xs, [pw[str(x)] for x in xs], 'o-', color=CAT[0], ms=3)
ax.axhline(0.8, color=GRID, lw=0.8, ls='--'); ax.axvline(S['T7_noise_ceiling']['spearman_brown'], color=CAT[1], lw=1)
ax.text(S['T7_noise_ceiling']['spearman_brown'] - 0.02, 0.05, 'noise\nceiling', color=CAT[1], fontsize=5.5, ha='right')
ax.set_xlabel('Simulated isoform-code effect (ρ)'); ax.set_ylabel('Power (α = 0.05)'); ax.set_ylim(0, 1.05)
ax.set_title('Sensitivity of the isoform test', loc='left')
save(fig, f'{FD}/Figure3'); print('ok')
