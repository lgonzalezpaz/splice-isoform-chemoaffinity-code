"""Extract locus-restricted splice-junction and read counts from remote, unindexed SMART-seq BAMs.

Usage: python 02_extract_splicing.py cells.tsv out.jsonl [n_workers]
cells.tsv: tab-separated, columns cell_id, url (header line required).
Output: one JSON object per cell with per-gene read counts, per-gene junction counts
(fragment-deduplicated by read name) and Pcdh variable-exon fragment counts.
Resumable: cells already present in out.jsonl are skipped.
"""
import sys, os, json, time, threading, collections, traceback
from concurrent.futures import ThreadPoolExecutor, as_completed
import requests
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from remote_bam import RemoteBAM, blocks_and_junctions
from chrom_map import UCSC2REFSEQ

ANN = json.load(open(os.path.join(HERE, '..', 'data_ref', 'adhesion_annotation_vM25.json')))
GENES = {g: v for g, v in ANN['genes'].items() if not g.startswith(('Pcdha', 'Pcdhb', 'Pcdhg'))}
PCDH = ANN['pcdh']
pc_start = min(v['start'] for v in PCDH.values()) - 1000
pc_end = max(v['end'] for v in PCDH.values()) + 1000
LOCI = [(g, v['chrom'], v['start'], v['end']) for g, v in GENES.items()]
LOCI.append(('PCDH_CLUSTER', 'chr18', pc_start, pc_end))
PC_EX = sorted((v['var_exon'][0], v['var_exon'][1], g) for g, v in PCDH.items())


def process(cell_id, url, session):
    t0 = time.time()
    rb = RemoteBAM(url, session=session, probe=32000)
    order = {r: i for i, r in enumerate(rb.refs)}
    loci = sorted(LOCI, key=lambda x: (order[UCSC2REFSEQ[x[1]]], x[2]))
    res = dict(cell_id=cell_id, url=url, genes={}, junctions={}, pcdh={})
    lo = 0; prev_rid = -1
    for g, ch, s, e in loci:
        rid = order[UCSC2REFSEQ[ch]]
        if rid != prev_rid:
            prev_rid = rid
        n = 0; jn = collections.defaultdict(set); pcd = collections.defaultdict(set)
        for pos1, cig, flag, qn in rb.fetch(UCSC2REFSEQ[ch], s, e, lo=lo):
            n += 1
            blocks, juncs = blocks_and_junctions(pos1, cig)
            for j in juncs:
                jn[j].add(qn)
            if g == 'PCDH_CLUSTER':
                for bs, be in blocks:
                    for xs, xe, pg in PC_EX:
                        if xs > be: break
                        if xe >= bs:
                            pcd[pg].add(qn)
        lo = getattr(rb, 'last_start', lo)
        res['genes'][g] = n
        res['junctions'][g] = {f"{a}-{b}": len(q) for (a, b), q in jn.items()}
        if g == 'PCDH_CLUSTER':
            res['pcdh'] = {k: len(v) for k, v in pcd.items()}
    import re as _re
    mm = _re.search(r'readFilesIn\s+(\S+)', rb.header_text)
    res['fastq'] = mm.group(1).split('/')[-1] if mm else None
    res['n_requests'] = rb.nreq; res['mbytes'] = round(rb.nbytes / 1e6, 2); res['sec'] = round(time.time() - t0, 1)
    return res


def main():
    cells, out = sys.argv[1], sys.argv[2]
    nw = int(sys.argv[3]) if len(sys.argv) > 3 else 16
    todo = [l.rstrip('\n').split('\t') for l in open(cells)][1:]
    done = set()
    if os.path.exists(out):
        for l in open(out):
            try: done.add(json.loads(l)['cell_id'])
            except Exception: pass
    todo = [t for t in todo if t[0] not in done]
    print(f'{len(todo)} cells to process, {len(done)} done', flush=True)
    lock = threading.Lock(); local = threading.local()

    def work(t):
        if not hasattr(local, 's'):
            local.s = requests.Session()
            local.s.mount('https://', requests.adapters.HTTPAdapter(pool_connections=2, pool_maxsize=2, max_retries=3))
        for attempt in range(3):
            try:
                r = process(t[0], t[1], local.s)
                with lock:
                    with open(out, 'a') as f: f.write(json.dumps(r) + '\n')
                return t[0], r['sec'], r['mbytes']
            except Exception as ex:
                err = traceback.format_exc()
                time.sleep(5)
        with open(out + '.errors', 'a') as f: f.write(t[0] + '\t' + err.replace('\n', ' | ') + '\n')
        return t[0], -1, 0

    t0 = time.time(); k = 0
    with ThreadPoolExecutor(nw) as ex:
        for fu in as_completed([ex.submit(work, t) for t in todo]):
            k += 1
            c, s, mb = fu.result()
            if k % 20 == 0:
                print(f'{k}/{len(todo)} last={c} {s}s {mb}MB elapsed={time.time()-t0:.0f}s', flush=True)


if __name__ == '__main__':
    main()
