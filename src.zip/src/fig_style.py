"""Shared figure style: Okabe-Ito categorical order (validated for CVD with direct labels), diverging blue-grey-orange."""
import matplotlib as mpl
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap

CAT = ['#0072B2', '#D55E00', '#009E73', '#CC79A7', '#E69F00', '#56B4E9']
INK, INK2, GRID = '#1a1a1a', '#555555', '#e6e6e6'
DIV = LinearSegmentedColormap.from_list('div', ['#08519c', '#6baed6', '#f2f2f2', '#fd8d3c', '#a63603'])
SEQ = LinearSegmentedColormap.from_list('seq', ['#f7fbff', '#9ecae1', '#3182bd', '#08306b'])
TYPES = ['23P', '4P', '5P-IT', '5P-ET', '5P-NP', '6P-IT', '6P-CT', 'BC', 'MC', 'BPC', 'NGC']
EXC = TYPES[:7]


def setup():
    mpl.rcParams.update({
        'font.family': 'DejaVu Sans', 'font.size': 7, 'axes.titlesize': 8, 'axes.labelsize': 7,
        'xtick.labelsize': 6.5, 'ytick.labelsize': 6.5, 'legend.fontsize': 6.5,
        'axes.edgecolor': INK2, 'axes.labelcolor': INK, 'xtick.color': INK2, 'ytick.color': INK2,
        'axes.spines.top': False, 'axes.spines.right': False, 'axes.linewidth': 0.6,
        'xtick.major.width': 0.6, 'ytick.major.width': 0.6, 'lines.linewidth': 1.5,
        'savefig.dpi': 600, 'pdf.fonttype': 42, 'svg.fonttype': 'none', 'figure.dpi': 150})


def panel(ax, letter, x=-0.18, y=1.06):
    ax.text(x, y, letter, transform=ax.transAxes, fontsize=10, fontweight='bold', va='bottom', ha='left', color=INK)


def save(fig, path):
    for ext in ['pdf', 'svg', 'png']:
        fig.savefig(f'{path}.{ext}', bbox_inches='tight', dpi=600 if ext == 'png' else None)
    plt.close(fig)
