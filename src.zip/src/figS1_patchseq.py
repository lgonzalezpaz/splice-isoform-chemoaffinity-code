"""Supplementary Figure S1: Patch-seq file identity assignment and replication of splicing and expression."""
import os as _os, sys as _sys
_sys.path.insert(0, _os.path.dirname(_os.path.abspath(__file__)) if 'src' in __file__ else _os.path.join(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))), 'src'))
from paths import ROOT, DATA, RES
import numpy as np, pandas as pd, matplotlib.pyplot as plt, os, sys, json
from scipy import stats
sys.path.insert(0, os.path.dirname(__file__))
from fig_style import *
setup()
R = f'{RES}'; FD = f'{ROOT}/figures'
I = ['Pvalb', 'Sst', 'Vip', 'Lamp5', 'Sncg']
idm = pd.read_csv(f'{R}/splicing/patchseq_bam_identity.csv')
t = pd.read_csv(f'{R}/splicing/tasic_events.csv').set_index('event'); p = pd.read_csv(f'{R}/splicing/patchseq_events.csv').set_index('event')
mt = pd.read_csv(f'{R}/expression/tasic_meanlog.csv', index_col=0); mp = pd.read_csv(f'{R}/expression/patchseq_meanlog.csv', index_col=0)
genes = [l.strip() for l in open(f'{ROOT}/data_ref/genes_cell_level.txt') if l.strip()]
genes = [g for g in genes if g in mt.index and g in mp.index]
out = {}
fig, axs = plt.subplots(1, 3, figsize=(7.2, 2.4)); plt.subplots_adjust(wspace=0.5)
ax = axs[0]; panel(ax, 'a', x=-0.3)
ax.scatter(idm.r_second, idm.r_best, s=3, c=np.where(idm.accepted, CAT[0], '#bdbdbd'), lw=0)
ax.plot([0.5, 1], [0.55, 1.05], color=GRID, lw=0.8)
ax.set_xlabel('r, second-best sample'); ax.set_ylabel('r, best-matching sample')
ax.text(0.03, 0.97, f'{int(idm.accepted.sum())}/{len(idm)} assigned\ntube agreement {idm.tube_match.mean()*100:.1f}%', transform=ax.transAxes, va='top', fontsize=6)
out['identity'] = dict(n=len(idm), accepted=int(idm.accepted.sum()), tube_agreement=float(idm.tube_match.mean()), median_r=float(idm.r_best.median()), median_margin=float((idm.r_best - idm.r_second).median()))
ax = axs[1]; panel(ax, 'b', x=-0.3)
xs, ys, cs = [], [], []
common = t.index.intersection(p.index)
for e in common:
    for k, s in enumerate(I):
        if t.loc[e, f'n|{s}'] >= 20 and p.loc[e, f'n|{s}'] >= 20:
            xs.append(t.loc[e, f'psi|{s}']); ys.append(p.loc[e, f'psi|{s}']); cs.append(CAT[k])
ax.scatter(xs, ys, s=3, c=cs, lw=0, alpha=0.7)
r = stats.pearsonr(xs, ys)[0]; rs = stats.spearmanr(xs, ys)[0]
ax.set_xlabel('PSI, dissociated SMART-seq'); ax.set_ylabel('PSI, Patch-seq')
ax.text(0.03, 0.97, f'r = {r:.3f}\nρ = {rs:.3f}\nn = {len(xs)} event × subclass', transform=ax.transAxes, va='top', fontsize=6)
for k, s in enumerate(I): ax.text(0.97, 0.05 + 0.08 * k, s, color=CAT[k], transform=ax.transAxes, ha='right', fontsize=5.5)
out['psi_replication'] = dict(pearson=float(r), spearman=float(rs), n=len(xs), n_events=int(len(common)))
ax = axs[2]; panel(ax, 'c', x=-0.3)
X = mt.loc[genes, I].to_numpy().ravel(); Y = mp.loc[genes, I].to_numpy().ravel()
ax.scatter(X, Y, s=3, c=np.repeat([CAT[:5]], len(genes), 0).ravel(), lw=0, alpha=0.7)
r = stats.pearsonr(X, Y)[0]
# subclass-specificity concordance (centred profiles)
Xc = (mt.loc[genes, I].T - mt.loc[genes, I].mean(1)).T.to_numpy().ravel(); Yc = (mp.loc[genes, I].T - mp.loc[genes, I].mean(1)).T.to_numpy().ravel()
rc = stats.pearsonr(Xc, Yc)[0]
ax.set_xlabel('log$_2$(CPM+1), SMART-seq'); ax.set_ylabel('log$_2$(CPM+1), Patch-seq')
ax.text(0.03, 0.97, f'r = {r:.3f}\ncentred r = {rc:.3f}\n{len(genes)} genes', transform=ax.transAxes, va='top', fontsize=6)
out['expr_replication'] = dict(pearson=float(r), centred_pearson=float(rc), n_genes=len(genes))
save(fig, f'{FD}/FigureS1')
json.dump(out, open(f'{R}/splicing/figureS1_stats.json', 'w'), indent=1); print(out)
