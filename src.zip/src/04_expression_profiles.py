"""Subclass-level gene expression profiles from SMART-seq v4 (Tasic et al. 2018, VISp) and Patch-seq (Gouwens et al. 2020).

For every gene: mean log2(CPM+1) and detection fraction per transcriptomic subclass, computed in two streaming passes
(library sizes, then aggregation) so that the full matrices never reside in memory.
Outputs: results/expression/{tasic,patchseq}_{meanlog,detect}.csv and cell-level CPM for selected genes.
"""
import os as _os, sys as _sys
_sys.path.insert(0, _os.path.dirname(_os.path.abspath(__file__)) if 'src' in __file__ else _os.path.join(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))), 'src'))
from paths import ROOT, DATA, RES
import os, sys, numpy as np, pandas as pd, glob
D = f'{DATA}'; OUT = f'{RES}/expression'; os.makedirs(OUT, exist_ok=True)
SUB = ['L2/3 IT', 'L4', 'L5 IT', 'L5 PT', 'NP', 'L6 IT', 'L6 CT', 'L6b', 'Pvalb', 'Sst', 'Vip', 'Lamp5', 'Sncg']
KEEP = [l.strip() for l in open(f'{ROOT}/data_ref/genes_cell_level.txt') if l.strip()]


def two_pass(path, groups, tag, sep=','):
    """groups: Series index=cell (column name) -> subclass label."""
    cols = pd.read_csv(path, nrows=0, sep=sep).columns
    gene_col = cols[0]
    use = [c for c in cols[1:] if c in groups.index]
    lib = pd.Series(0.0, index=use)
    for ch in pd.read_csv(path, chunksize=2000, usecols=[gene_col] + use, sep=sep, index_col=0):
        lib += ch.sum(0)
    g = groups.loc[use]
    labs = [s for s in SUB if (g == s).any()]
    M = {s: np.where(g.values == s)[0] for s in labs}
    meanlog, detect, cellkeep = [], [], []
    for ch in pd.read_csv(path, chunksize=2000, usecols=[gene_col] + use, sep=sep, index_col=0):
        X = ch.to_numpy(np.float64)
        L = np.log2(X / lib.values[None, :] * 1e6 + 1)
        meanlog.append(pd.DataFrame({s: L[:, M[s]].mean(1) for s in labs}, index=ch.index))
        detect.append(pd.DataFrame({s: (X[:, M[s]] > 0).mean(1) for s in labs}, index=ch.index))
        k = ch.index.isin(KEEP)
        if k.any():
            cellkeep.append(pd.DataFrame(L[k], index=ch.index[k], columns=use))
    ml = pd.concat(meanlog); dt = pd.concat(detect)
    ml.to_csv(f'{OUT}/{tag}_meanlog.csv'); dt.to_csv(f'{OUT}/{tag}_detect.csv')
    pd.concat(cellkeep).T.astype(np.float32).to_pickle(f'{OUT}/{tag}_cells_log2cpm_selected.pkl')
    pd.DataFrame({'cell': use, 'subclass': g.values, 'lib': lib.values}).to_csv(f'{OUT}/{tag}_cells.csv', index=False)
    print(tag, ml.shape, g.value_counts().to_dict())


if __name__ == '__main__':
    which = sys.argv[1]
    if which == 'tasic':
        m = pd.read_csv(f'{D}/tasic/GSE115746_complete_metadata_28706-cells.csv.gz')
        m = m[m.source_name.str.contains('VISp', na=False) & (m.sequencing_qc_pass_fail == 'Pass') & m.cell_subclass.isin(SUB)]
        two_pass(f'{D}/tasic/GSE115746_cells_exon_counts.csv.gz', m.set_index('sample_name').cell_subclass, 'tasic')
    else:
        meta = pd.read_csv(glob.glob(f'{D}/patchseq/20200625_patchseq_metadata_mouse/*.csv')[0])
        alias = meta['corresponding_AIT2.3.1_alias'].fillna('')
        def sub(a):
            for s in ['L2/3 IT', 'L4', 'L5 IT', 'L5 PT', 'NP', 'L6 IT', 'L6 CT', 'L6b', 'Pvalb', 'Sst', 'Vip', 'Lamp5', 'Sncg']:
                if a.startswith(s + ' ') or a == s: return s
            if a.startswith('L4 IT'): return 'L4'
            if a.startswith('L5 ET') or a.startswith('L5 PT'): return 'L5 PT'
            if a.startswith('L5 NP') or a.startswith('L6 NP'): return 'NP'
            return None
        meta['subclass'] = alias.map(sub)
        meta = meta.dropna(subset=['subclass'])
        meta[['transcriptomics_sample_id', 'cell_specimen_id', 'corresponding_AIT2.3.1_alias', 'subclass', 'structure', 'cell_soma_normalized_depth', 'dendrite_type']].to_csv(f'{OUT}/patchseq_meta_used.csv', index=False)
        two_pass(glob.glob(f'{D}/patchseq/20200513_Mouse_PatchSeq_Release_count.v2/*.csv')[0], meta.set_index('transcriptomics_sample_id').subclass, 'patchseq')
