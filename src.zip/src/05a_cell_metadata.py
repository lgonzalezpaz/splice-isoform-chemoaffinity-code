"""Cell metadata (subclass labels) for junction tables: SMART-seq v4 VISp cells."""
import os, sys, pandas as pd
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from paths import DATA, RES
os.makedirs(f'{RES}/splicing', exist_ok=True)
m = pd.read_csv(f'{DATA}/tasic/GSE115746_complete_metadata_28706-cells.csv.gz')
s = pd.read_csv(f'{DATA}/tasic/cells_selected.tsv', sep='\t')
m = m[m.sample_name.isin(s.cell_id)][['sample_name', 'cell_subclass', 'cell_cluster', 'donor_id', 'dissected_layer']]
m.rename(columns={'sample_name': 'cell_id', 'cell_subclass': 'subclass'}).to_csv(f'{RES}/splicing/tasic_cells_meta.csv', index=False)
print(len(m))
