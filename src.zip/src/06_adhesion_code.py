"""Isoform-resolved adhesion compatibility and its relation to connectomic specificity (MICrONS).

For every presynaptic (a) x postsynaptic (b) MICrONS cell type pair we compute compatibility scores C_k(a,b)
for curated trans-synaptic interactions (data_ref/interactions.csv), optionally gated by the splice isoforms
measured from SMART-seq junction reads (SS4 of neurexins, meA/meB of LAR-RPTPs, the teneurin insert), and test
their association with the geometry-corrected interaction term of MICrONS connectivity.

Statistical design (pre-specified):
  T1  Spearman correlation between each double-centred compatibility matrix and the double-centred
      connectivity interaction matrix; type-label permutation null (Mantel-like, same permutation for rows
      and columns, 10,000 permutations).
  T2  Cross-validated bilinear (ridge) model on all interactions: leave-one-pair-out and leave-one-type-out
      prediction; nulls from (i) type-label permutation and (ii) 1,000 random ligand-receptor-like gene-pair sets
      matched in number and in across-type expression variability.
  T3  Isoform contribution: isoform-gated vs isoform-blind features; null from permuting PSI vectors across
      types (2,000 permutations).
  T4  Clustered-protocadherin similarity (predicted repulsive) vs interaction.
  T5  Consolidation proxies (multisynaptic fraction, mean synapse size) vs compatibility controlling for the
      interaction term (partial Spearman).
"""
import os as _os, sys as _sys
_sys.path.insert(0, _os.path.dirname(_os.path.abspath(__file__)) if 'src' in __file__ else _os.path.join(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))), 'src'))
from paths import ROOT, DATA, RES
import os, sys, json, numpy as np, pandas as pd
from scipy import stats
from sklearn.linear_model import Ridge
R = os.environ.get('RES', f'{RES}'); OUT = f'{R}/code' + os.environ.get('TAG', ''); os.makedirs(OUT, exist_ok=True)
rng = np.random.default_rng(20261022)
TYPES = ['23P', '4P', '5P-IT', '5P-ET', '5P-NP', '6P-IT', '6P-CT', 'BC', 'MC', 'BPC', 'NGC']
MAPS = {
    'main': {'23P': 'L2/3 IT', '4P': 'L4', '5P-IT': 'L5 IT', '5P-ET': 'L5 PT', '5P-NP': 'NP', '6P-IT': 'L6 IT', '6P-CT': 'L6 CT',
             'BC': 'Pvalb', 'MC': 'Sst', 'BPC': 'Vip', 'NGC': 'Lamp5'},
}
MAPS['alt_NGC_Sncg'] = dict(MAPS['main'], NGC='Sncg')        # neurogliaform-like Sncg/Lamp5 ambiguity
MAPS['alt_6CT_L6b'] = dict(MAPS['main'], **{'6P-CT': 'L6b'})  # deep-layer ambiguity
ALIAS = {'Adgrl1': 'Lphn1', 'Adgrl2': 'Lphn2', 'Adgrl3': 'Lphn3'}
EXPR = os.environ.get('EXPR', 'tasic')
MAPNAME = os.environ.get('MAP', 'main'); MAP = MAPS[MAPNAME]
OUTCOME = os.environ.get('OUTCOME', 'interaction')  # interaction | interaction_reldepth | interaction_binary
NPERM = int(os.environ.get('NPERM', 10000)); NRAND = int(os.environ.get('NRAND', 1000))
ml = pd.read_csv(f'{R}/expression/{EXPR}_meanlog.csv', index_col=0)
if EXPR == 'patchseq':  # interneurons only: fill excitatory subclasses from SMART-seq (dissociated) data
    t = pd.read_csv(f'{R}/expression/tasic_meanlog.csv', index_col=0)
    ml = ml[[c for c in ['Pvalb', 'Sst', 'Vip', 'Lamp5', 'Sncg'] if c in ml.columns]]
    for c in t.columns:
        if c not in ml.columns: ml[c] = t.loc[ml.index.intersection(t.index), c]
lin = 2 ** ml - 1
ev = pd.read_csv(f'{R}/splicing/tasic_events.csv')
if EXPR == 'patchseq' and os.path.exists(f'{R}/splicing/patchseq_events.csv'):
    pe = pd.read_csv(f'{R}/splicing/patchseq_events.csv')
key = pd.read_csv(f'{R}/splicing/key_events.csv')
inter = pd.read_csv(os.environ.get('INTER', f'{ROOT}/data_ref/interactions.csv'))
tp = pd.read_csv(f'{R}/microns/type_pair_stats.csv')


_LCACHE = {}


def L(g, subcls):
    k = (g, tuple(subcls))
    if k not in _LCACHE: _LCACHE[k] = lin.loc[g, list(subcls)].to_numpy(float)
    return _LCACHE[k]


_PCACHE = {}


def G(g):
    return ALIAS.get(g, g) if ALIAS.get(g, g) in lin.index else g


def psi_vec(event_ids, subcls, src=None):
    src = ev if src is None else src
    t = src.set_index('event')
    t = t.loc[[e for e in event_ids if e in t.index]]
    if len(t) == 0: return None
    # read-weighted mean over the exons belonging to the same rule (e.g., meA 3/6/9-residue variants)
    num = np.zeros(len(subcls)); den = np.zeros(len(subcls))
    for _, r in t.iterrows():
        for i, s in enumerate(subcls):
            p, n = r.get(f'psi|{s}', np.nan), r.get(f'n|{s}', 0)
            if np.isfinite(p) and n > 0: num[i] += p * n; den[i] += n
    v = np.divide(num, den, out=np.full(len(subcls), np.nan), where=den > 0)
    return np.where(np.isnan(v), np.nanmean(v), v)


PSI_OVERRIDE = {}  # (rule, gene) -> vector (used by PSI-permutation null)


def gate(rule, gene, subcls, use_iso):
    if rule in ('none', 'isoform') or not use_iso: return np.ones(len(subcls))
    base = rule.replace('minus', '').replace('plus', '')
    if (base, gene) in PSI_OVERRIDE: p = PSI_OVERRIDE[(base, gene)]
    else:
        ck = (base, gene, tuple(subcls))
        if ck not in _PCACHE:
            k = key[(key.rule == base) & (key.gene == gene)]
            _PCACHE[ck] = psi_vec(k.event.tolist(), subcls) if len(k) else None
        p = _PCACHE[ck]
    if p is None: return np.ones(len(subcls))
    return p if rule.endswith('plus') else 1 - p


def side(spec, rule, subcls, use_iso):
    parts = spec.split('&'); vals = []
    for pi, part in enumerate(parts):
        v = np.zeros(len(subcls))
        for g in part.split('|'):
            gg = G(g)
            if gg not in lin.index: continue
            v += L(gg, subcls) * (gate(rule, g, subcls, use_iso) if pi == 0 else 1)
        vals.append(np.log2(1 + v))
    sc = [x / x.max() if x.max() > 0 else x for x in vals]
    return np.sqrt(sc[0] * sc[1]) if len(sc) == 2 else sc[0]


def build(subcls, use_iso=True):
    F = {}
    for _, r in inter.iterrows():
        if r['mode'] == 'homo_repulsive': continue
        if r['mode'] == 'homo':
            acc = [np.minimum.outer(side(g, 'none', subcls, False), side(g, 'none', subcls, False)) for g in r.pre_gene.split('|') if G(g) in lin.index]
            F[r.id] = np.mean(acc, 0)
        else:
            F[r.id] = np.outer(side(r.pre_gene, r.isoform_rule, subcls, use_iso), side(r.post_gene, 'none', subcls, use_iso))
    return F


def dcenter(M, W):
    I = M.copy()
    for _ in range(60):
        I = I - (np.nansum(I * W, 1) / np.nansum(W, 1))[:, None]
        I = I - (np.nansum(I * W, 0) / np.nansum(W, 0))[None, :]
    return I


def mat(col):
    return tp.pivot(index='pre_type', columns='post_type', values=col).reindex(index=TYPES, columns=TYPES).to_numpy()


def sp(x, y):
    m = np.isfinite(x) & np.isfinite(y)
    return stats.spearmanr(x[m], y[m])[0]


def featmat(F, W):
    return np.column_stack([dcenter(F[k], W).ravel() for k in F])


def cv_predict(X, y, scheme, alpha=10.0):
    """Ridge CV; returns out-of-fold predictions. scheme: 'pair' (leave-one-pair-out) or 'type' (leave-one-type-out:
    hold out every pair whose pre- or post-type is t)."""
    n = len(TYPES); pred = np.full(len(y), np.nan)
    A = np.repeat(np.arange(n), n); B = np.tile(np.arange(n), n)
    folds = [np.array([i]) for i in range(len(y))] if scheme == 'pair' else [np.where((A == t) | (B == t))[0] for t in range(n)]
    Xs = (X - X.mean(0)) / (X.std(0) + 1e-12)
    if scheme == 'pair':  # exact closed-form leave-one-out for ridge with unpenalised intercept
        X1 = np.column_stack([np.ones(len(y)), Xs]); Dg = np.eye(X1.shape[1]) * alpha; Dg[0, 0] = 0
        H = X1 @ np.linalg.solve(X1.T @ X1 + Dg, X1.T)
        fit = H @ y
        return y - (y - fit) / (1 - np.diag(H))
    for te in folds:
        tr = np.setdiff1d(np.arange(len(y)), te)
        m = Ridge(alpha=alpha).fit(Xs[tr], y[tr])
        p = m.predict(Xs[te])
        if scheme == 'pair': pred[te] = p
        else:
            pred[te] = np.where(np.isnan(pred[te]), p, (pred[te] + p) / 2)
    return pred


def cv_score(X, y, scheme):
    p = cv_predict(X, y, scheme)
    return sp(p, y)


if __name__ == '__main__':
    Iobs = mat(OUTCOME); Eexp = mat('E'); W = np.sqrt(Eexp)
    y = Iobs.ravel()
    sub = [MAP[t] for t in TYPES]
    F_iso = build(sub, True); F_blind = build(sub, False)
    ids = list(F_iso)
    X_iso = featmat(F_iso, W); X_blind = featmat(F_blind, W)
    np.save(f'{OUT}/features.npy', dict(iso=F_iso, blind=F_blind, ids=ids), allow_pickle=True)
    res = {'map': MAPNAME, 'expr': EXPR, 'outcome': OUTCOME}

    # ---------- T1: per-interaction and aggregate correlations with type-label permutation
    perms = [rng.permutation(len(TYPES)) for _ in range(NPERM)]
    per = []
    for k in ids:
        for tag, F in [('iso', F_iso), ('blind', F_blind)]:
            x = dcenter(F[k], W)
            r0 = sp(x.ravel(), y)
            null = np.array([sp(x[np.ix_(p, p)].ravel(), y) for p in perms[:2000]])
            per.append(dict(id=k, family=inter.set_index('id').loc[k, 'family'], rule=inter.set_index('id').loc[k, 'isoform_rule'], version=tag,
                            rho=r0, p_perm=(1 + np.sum(np.abs(null) >= abs(r0))) / (1 + len(null))))
    per = pd.DataFrame(per)
    from statsmodels.stats.multitest import multipletests
    for v in ['iso', 'blind']:
        m = per.version == v
        per.loc[m, 'q'] = multipletests(per.loc[m, 'p_perm'], method='fdr_bh')[1]
    per.to_csv(f'{OUT}/T1_per_interaction.csv', index=False)

    # ---------- T2: cross-validated bilinear model
    cv = {}
    for scheme in ['pair', 'type']:
        cv[f'{scheme}_iso'] = cv_score(X_iso, y, scheme)
        cv[f'{scheme}_blind'] = cv_score(X_blind, y, scheme)
    # label-permutation null for CV (permute outcome matrix rows/cols jointly)
    Y = Iobs
    nullcv = []
    for p in perms[:300]:
        yp = Y[np.ix_(p, p)].ravel()
        nullcv.append(cv_score(X_iso, yp, 'pair'))
    cv['pair_iso_p_perm'] = (1 + np.sum(np.array(nullcv) >= cv['pair_iso'])) / (1 + len(nullcv))
    # random gene-pair null matched for across-type variability
    expressed = lin.index[(ml[sub].max(1) > 3)]
    cvv = ml.loc[expressed, sub].std(1)
    cur_genes = sorted({G(g) for s in inter.pre_gene.tolist() + inter.post_gene.tolist() for g in s.replace('&', '|').split('|') if G(g) in lin.index})
    q_bins = pd.qcut(cvv, 10, labels=False, duplicates='drop')
    target_bins = q_bins.reindex(cur_genes).dropna().astype(int).tolist()
    pool = {b: q_bins.index[q_bins == b].tolist() for b in set(q_bins)}
    rand_scores = []; rand_t1 = []
    nfeat = len(ids)
    for it in range(NRAND):
        F = {}
        for j in range(nfeat):
            g1 = rng.choice(pool[rng.choice(target_bins)]); g2 = rng.choice(pool[rng.choice(target_bins)])
            a = np.log2(1 + lin.loc[g1, sub].to_numpy()); b = np.log2(1 + lin.loc[g2, sub].to_numpy())
            F[j] = np.outer(a / a.max(), b / b.max())
        Xr = featmat(F, W)
        rand_scores.append(cv_score(Xr, y, 'pair'))
        rand_t1.append(sp(dcenter(np.mean(list(F.values()), 0), W).ravel(), y))
    rand_scores = np.array(rand_scores)
    cv['pair_iso_pct_vs_random_genes'] = float(np.mean(rand_scores < cv['pair_iso']))
    cv['p_random_genes'] = float((1 + np.sum(rand_scores >= cv['pair_iso'])) / (1 + len(rand_scores)))
    cv['random_genes_median'] = float(np.median(rand_scores)); cv['random_genes_q95'] = float(np.quantile(rand_scores, 0.95))
    np.save(f'{OUT}/T2_random_gene_cv.npy', rand_scores)
    np.save(f'{OUT}/T2_perm_cv.npy', np.array(nullcv))
    for scheme in ['pair', 'type']:
        np.save(f'{OUT}/T2_pred_{scheme}_iso.npy', cv_predict(X_iso, y, scheme))
        np.save(f'{OUT}/T2_pred_{scheme}_blind.npy', cv_predict(X_blind, y, scheme))
    res['T2'] = cv

    # ---------- T3: isoform contribution, PSI-permutation null
    delta = cv['pair_iso'] - cv['pair_blind']
    iso_rules = inter[inter.isoform_rule.isin(['SS4minus', 'SS4plus', 'MEBplus', 'MEAplus', 'TENMminus'])]
    gated = [(r.replace('minus', '').replace('plus', ''), g) for r, spec in zip(iso_rules.isoform_rule, iso_rules.pre_gene)
             for g in spec.split('&')[0].split('|')]
    gated = sorted(set(gated))
    true_psi = {}
    for base, g in gated:
        k = key[(key.rule == base) & (key.gene == g)]
        v = psi_vec(k.event.tolist(), sub) if len(k) else None
        if v is not None: true_psi[(base, g)] = v
    dnull = []
    for it in range(int(os.environ.get('NPSI', 1000))):
        PSI_OVERRIDE.clear()
        for kk, v in true_psi.items(): PSI_OVERRIDE[kk] = v[rng.permutation(len(v))]
        Fp = build(sub, True)
        dnull.append(cv_score(featmat(Fp, W), y, 'pair') - cv['pair_blind'])
    PSI_OVERRIDE.clear()
    dnull = np.array(dnull)
    res['T3'] = dict(delta_cv_rho=delta, p_psi_perm=float((1 + np.sum(dnull >= delta)) / (1 + len(dnull))), null_median=float(np.median(dnull)),
                     n_gated_genes=len(true_psi), gated=[f'{a}:{b}' for a, b in true_psi])
    np.save(f'{OUT}/T3_psi_perm_delta.npy', dnull)
    # bootstrap over type pairs for delta
    boots = []
    pi = cv_predict(X_iso, y, 'pair'); pb = cv_predict(X_blind, y, 'pair')
    for b in range(2000):
        s = rng.integers(0, len(y), len(y))
        boots.append(sp(pi[s], y[s]) - sp(pb[s], y[s]))
    res['T3']['delta_ci95'] = list(np.percentile(boots, [2.5, 97.5]))

    # ---------- aggregate ACI (equal weights) T1
    A_iso = dcenter(np.mean([F_iso[k] for k in ids], 0), W); A_bl = dcenter(np.mean([F_blind[k] for k in ids], 0), W)
    for nm, A in [('ACI_iso', A_iso), ('ACI_blind', A_bl)]:
        r0 = sp(A.ravel(), y); null = np.array([sp(A[np.ix_(p, p)].ravel(), y) for p in perms])
        res[nm] = dict(rho=r0, p_perm=float((1 + np.sum(np.abs(null) >= abs(r0))) / (1 + len(null))),
                       pct_vs_random_sets=float(np.mean(np.array(rand_t1) < r0)))

    # ---------- T4: clustered Pcdh similarity
    pcf = f'{R}/splicing/tasic_events_pcdh.csv'
    pc = pd.read_csv(pcf, index_col=0)
    cols = [c for c in pc.columns if c.startswith('Pcdh')]
    X = pc[cols].to_numpy(float); tot = X.sum(1); keep = tot >= 10
    Xn = X[keep] / np.linalg.norm(X[keep], axis=1, keepdims=True); lab = pc.subclass.to_numpy()[keep]
    S = np.full((len(TYPES), len(TYPES)), np.nan)
    for i, a in enumerate(sub):
        for j, b in enumerate(sub):
            A_ = Xn[lab == a]; B_ = Xn[lab == b]
            if len(A_) < 5 or len(B_) < 5: continue
            M = A_ @ B_.T
            if a == b: M = M[~np.eye(len(A_), dtype=bool)]
            S[i, j] = M.mean()
    Sd = dcenter(np.nan_to_num(S, nan=np.nanmean(S)), W)
    r0 = sp(Sd.ravel(), y); null = np.array([sp(Sd[np.ix_(p, p)].ravel(), y) for p in perms])
    res['T4_pcdh'] = dict(rho=r0, p_perm=float((1 + np.sum(np.abs(null) >= abs(r0))) / (1 + len(null))), n_cells=int(keep.sum()))
    np.save(f'{OUT}/T4_pcdh_similarity.npy', S)
    # within-type vs between-type similarity
    diag = np.diag(S); off = S[~np.eye(len(TYPES), dtype=bool)]
    res['T4_pcdh']['diag_mean'] = float(np.nanmean(diag)); res['T4_pcdh']['offdiag_mean'] = float(np.nanmean(off))


    # ---------- T6: controls for generic transcriptomic identity and the E/I class-block structure
    hv = ml[sub]; hv = hv[hv.max(axis=1) > 3]; hv = hv.loc[hv.var(axis=1).sort_values().index[-2000:]]
    Sg = np.corrcoef(hv.T.values); Sgd = dcenter(Sg, W)
    cls = np.array([0] * 7 + [1] * 4)
    blk = np.zeros_like(Iobs)
    for a_ in (0, 1):
        for b_ in (0, 1):
            mm = np.ix_(cls == a_, cls == b_); blk[mm] = np.average(Iobs[mm], weights=W[mm])
    resid = (Iobs - blk).ravel()

    def pcor(x, yv, z):
        rx, ry, rz = stats.rankdata(x), stats.rankdata(yv), stats.rankdata(z)
        ex = rx - np.polyval(np.polyfit(rz, rx, 1), rz); ey = ry - np.polyval(np.polyfit(rz, ry, 1), rz)
        r_, p_ = stats.pearsonr(ex, ey); return float(r_), float(p_)
    t6 = dict(classblock_R2_weighted=float(1 - np.sum(W * (Iobs - blk) ** 2) / np.sum(W * (Iobs - np.average(Iobs, weights=W)) ** 2)),
              generic_similarity_rho=sp(Sgd.ravel(), y),
              pcdh_partial_given_generic=pcor(Sd.ravel(), y, Sgd.ravel()),
              ACI_iso_partial_given_generic=pcor(A_iso.ravel(), y, Sgd.ravel()),
              cv_pair_generic_only=cv_score(Sgd.ravel()[:, None], y, 'pair'),
              cv_pair_iso_plus_generic=cv_score(np.column_stack([X_iso, Sgd.ravel()]), y, 'pair'),
              resid_cv_pair_iso=cv_score(X_iso, resid, 'pair'), resid_cv_pair_blind=cv_score(X_blind, resid, 'pair'),
              resid_pcdh_rho=sp(Sd.ravel(), resid), resid_ACI_iso_rho=sp(A_iso.ravel(), resid))
    rr = []
    for it in range(min(NRAND, 300)):
        Fr = {}
        for j in range(nfeat):
            g1 = rng.choice(pool[rng.choice(target_bins)]); g2 = rng.choice(pool[rng.choice(target_bins)])
            a = np.log2(1 + lin.loc[g1, sub].to_numpy()); b = np.log2(1 + lin.loc[g2, sub].to_numpy())
            Fr[j] = np.outer(a / a.max(), b / b.max())
        rr.append(cv_score(featmat(Fr, W), resid, 'pair'))
    t6['resid_random_genes_median'] = float(np.median(rr)); t6['resid_p_random_genes'] = float((1 + np.sum(np.array(rr) >= t6['resid_cv_pair_iso'])) / (1 + len(rr)))
    np.save(f'{OUT}/T6_generic_similarity.npy', Sg)
    res['T6'] = t6

    # ---------- T3b: rule-level directional test (does gating by the measured isoform improve each family's alignment?)
    t3b = {}
    for rule in ['SS4', 'MEB', 'MEA', 'TENM']:
        rows_r = inter[inter.isoform_rule.str.startswith(rule)]
        if len(rows_r) == 0: continue
        ks = rows_r.id.tolist()
        obs_d = np.mean([sp(dcenter(F_iso[k], W).ravel(), y) - sp(dcenter(F_blind[k], W).ravel(), y) for k in ks])
        nd = []
        genes_r = [kk for kk in true_psi if kk[0] == rule]
        for it in range(500):
            PSI_OVERRIDE.clear()
            for kk in genes_r: PSI_OVERRIDE[kk] = true_psi[kk][rng.permutation(len(TYPES))]
            Fp = {}
            for _, r in rows_r.iterrows():
                Fp[r.id] = np.outer(side(r.pre_gene, r.isoform_rule, sub, True), side(r.post_gene, 'none', sub, True))
            nd.append(np.mean([sp(dcenter(Fp[k], W).ravel(), y) - sp(dcenter(F_blind[k], W).ravel(), y) for k in ks]))
        PSI_OVERRIDE.clear()
        t3b[rule] = dict(n_interactions=len(ks), mean_delta_rho=float(obs_d), p_one_sided=float((1 + np.sum(np.array(nd) >= obs_d)) / (1 + len(nd))))
    res['T3b'] = t3b

    # ---------- T7: noise ceiling of the connectivity interaction matrix (split-half over presynaptic neurons)
    O = np.load(f'{R}/microns/O_main.npy'); E_ = np.load(f'{R}/microns/E_main.npy')
    pre = pd.read_csv(f'{R}/microns/pre_neurons.csv'); grp = pre.cell_type.to_numpy()
    sh = []
    for it in range(200):
        Om = [np.zeros((11, 11)), np.zeros((11, 11))]; Em = [np.zeros((11, 11)), np.zeros((11, 11))]
        for k_, t in enumerate(TYPES):
            ix = rng.permutation(np.where(grp == t)[0]); h = len(ix) // 2
            for hh, part in enumerate([ix[:h], ix[h:]]):
                Om[hh][k_] = O[part].sum(0); Em[hh][k_] = E_[part].sum(0)
        I1 = dcenter(np.log2((Om[0] + 0.5) / (Em[0] + 0.5)), W); I2 = dcenter(np.log2((Om[1] + 0.5) / (Em[1] + 0.5)), W)
        sh.append(sp(I1.ravel(), I2.ravel()))
    r_half = float(np.median(sh)); res['T7_noise_ceiling'] = dict(split_half_rho=r_half, spearman_brown=float(2 * r_half / (1 + r_half)))

    # ---------- T8: sensitivity (power) of the isoform test on synthetic connectomes generated by an isoform-gated code
    ss4_ids = inter[inter.isoform_rule.str.startswith(('SS4', 'MEB', 'MEA', 'TENM'))].id.tolist()
    sig = np.mean([dcenter(F_iso[k], W) for k in ss4_ids], 0).ravel(); sig = (sig - sig.mean()) / sig.std()
    perm_X = []
    for it in range(100):
        PSI_OVERRIDE.clear()
        for kk, v in true_psi.items(): PSI_OVERRIDE[kk] = v[rng.permutation(len(v))]
        perm_X.append(featmat(build(sub, True), W))
    PSI_OVERRIDE.clear()
    power = {}
    for rho_true in [0.3, 0.5, 0.7, 0.9]:
        hits = 0; nsim = 100
        for sim in range(nsim):
            noise = rng.standard_normal(len(y))
            ys = rho_true * sig + np.sqrt(1 - rho_true ** 2) * noise
            d0 = cv_score(X_iso, ys, 'pair') - cv_score(X_blind, ys, 'pair')
            dn = [cv_score(Xp, ys, 'pair') - cv_score(X_blind, ys, 'pair') for Xp in perm_X]
            hits += (1 + np.sum(np.array(dn) >= d0)) / (1 + len(dn)) <= 0.05
        power[str(rho_true)] = hits / nsim
    res['T8_power'] = power

    # ---------- T5: consolidation proxies
    pred_full = Ridge(alpha=10).fit((X_iso - X_iso.mean(0)) / (X_iso.std(0) + 1e-12), y).predict((X_iso - X_iso.mean(0)) / (X_iso.std(0) + 1e-12))
    cvp = np.load(f'{OUT}/T2_pred_pair_iso.npy')
    t5 = {}
    for col in ['multi_frac', 'mean_log_size', 'syn_per_conn']:
        z = mat(col).ravel()
        zd = dcenter(mat(col), W).ravel()
        ok = np.isfinite(zd) & np.isfinite(cvp)
        # partial Spearman: rank-residualize on interaction
        rz = stats.rankdata(zd[ok]); rp = stats.rankdata(cvp[ok]); ry = stats.rankdata(y[ok])
        res_z = rz - np.polyval(np.polyfit(ry, rz, 1), ry); res_p = rp - np.polyval(np.polyfit(ry, rp, 1), ry)
        pr = stats.pearsonr(res_z, res_p)
        t5[col] = dict(rho_with_interaction=sp(zd, y), rho_with_cvpred=sp(zd, cvp), partial_rho_given_interaction=pr[0], partial_p=pr[1])
    res['T5'] = t5
    json.dump(res, open(f'{OUT}/summary.json', 'w'), indent=1, default=float)
    print(json.dumps(res, indent=1, default=float))
