"""Central path configuration. ROOT is the repository root; DATA holds downloaded public inputs
(override with the environment variable DATA_DIR)."""
import os
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA = os.environ.get('DATA_DIR', os.path.join(ROOT, 'data'))
RES = os.environ.get('RES', os.path.join(ROOT, 'results'))
