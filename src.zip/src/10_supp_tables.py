"""Supplementary Tables S1 (curated interactions) and S2 (type-dependent events) for the DOCX builder."""
import os, sys, json, numpy as np, pandas as pd
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from paths import ROOT, RES
it = pd.read_csv(f'{ROOT}/data_ref/interactions.csv')
rules = {'none': '—', 'SS4minus': 'SS4⁻', 'SS4plus': 'SS4⁺', 'MEBplus': 'meB⁺', 'MEAplus': 'meA⁺', 'TENMminus': 'insert⁻', 'isoform': 'isoform-specific homophilic'}
modes = {'hetero': 'heterophilic', 'homo': 'homophilic', 'homo_repulsive': 'homophilic (repulsive)'}
rows = [[r.id, r.family, r.pre_gene.replace('|', ', ').replace('&', ' + '), r.post_gene.replace('|', ', '), modes[r['mode']], rules[r.isoform_rule],
         '[' + '; '.join('@' + k for k in r.refs.split(';')) + ']'] for _, r in it.iterrows()]
T = {'Table S1': dict(caption='Supplementary Table 1 | Curated trans-synaptic interactions, splice rules and supporting references. Gene groups are summed; "+" denotes a tripartite complex (geometric mean of components). Adgrl1–3 correspond to Lphn1–3 in the expression matrices. CPCDH was analysed separately as similarity (test T4).',
                      header=['ID', 'Family', 'Presynaptic', 'Postsynaptic', 'Mode', 'Splice rule', 'References'], rows=rows, widths=[1500, 1100, 1700, 1500, 1000, 900, 1300])}
ev = pd.read_csv(f'{RES}/splicing/tasic_events.csv'); s = ev[ev.alternative & (ev.q < 0.05)]
S = ['L2/3 IT', 'L4', 'L5 IT', 'L5 PT', 'NP', 'L6 IT', 'L6 CT', 'L6b', 'Pvalb', 'Sst', 'Vip', 'Lamp5', 'Sncg']
rows = []
for _, r in s.sort_values(['gene', 'exon']).iterrows():
    ge = [r[f'psi|{x}'] for x in S[:8] if np.isfinite(r[f'psi|{x}'])]; gi = [r[f'psi|{x}'] for x in S[8:] if np.isfinite(r[f'psi|{x}'])]
    rows.append([f'*{r.gene}*', r.type, r.exon.replace('@', ' skip '), str(int(r.length)), f'{np.mean(ge):.2f}' if ge else 'n.d.',
                 f'{np.mean(gi):.2f}' if gi else 'n.d.', f'{r.psi_range:.2f}', str(int(r.n_inc + r.n_exc)), f'{r.q:.3f}'])
T['Table S2'] = dict(caption='Supplementary Table 2 | Splicing events with cell-type-dependent inclusion (permutation FDR < 0.05) among 1,543 VISp SMART-seq v4 neurons. Coordinates are GRCm38 (1-based); for cassette exons the skipping junction is given. Mean Ψ across glutamatergic and GABAergic subclasses; range, max − min across 13 subclasses.',
                     header=['Gene', 'Type', 'Exon / junctions', 'nt', 'Ψ glut.', 'Ψ GABA', 'Range', 'Fragments', 'q'], rows=rows, widths=[800, 800, 3000, 450, 700, 700, 700, 900, 700])
json.dump(T, open(f'{ROOT}/manuscript/supp_tables.json', 'w'), indent=1, ensure_ascii=False)
pd.DataFrame(T['Table S2']['rows'], columns=T['Table S2']['header']).to_csv(f'{RES}/TableS2.csv', index=False)
print(len(T['Table S1']['rows']), len(T['Table S2']['rows']))
