"""Type-to-type synaptic specificity in MICrONS minnie65 (v1412) relative to a geometric (Peters-rule) null.

Inputs (static MICrONS release, see README):
  aibs_metamodel_celltypes_v661, nucleus_detection_v0, proofreading_status_and_strategy (v1412),
  connections_with_nuclei (v1412; soma-to-soma synapse counts and summed cleft sizes).
Outputs (results/microns/):
  pre_neurons.csv, type_pair_stats.csv (O, E, log2 O/E, interaction, bootstrap CIs, multisynaptic
  fraction, synapse size), and null-model variants for sensitivity analysis.
"""
import os as _os, sys as _sys
_sys.path.insert(0, _os.path.dirname(_os.path.abspath(__file__)) if 'src' in __file__ else _os.path.join(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))), 'src'))
from paths import ROOT, DATA, RES
import os, sys, numpy as np, pandas as pd
D = sys.argv[1] if len(sys.argv) > 1 else f'{DATA}/microns'
OUT = sys.argv[2] if len(sys.argv) > 2 else f'{RES}/microns'
os.makedirs(OUT, exist_ok=True)
rng = np.random.default_rng(1)
TYPES = ['23P', '4P', '5P-IT', '5P-ET', '5P-NP', '6P-IT', '6P-CT', 'BC', 'MC', 'BPC', 'NGC']
VOX = np.array([4.0, 4.0, 40.0]) / 1000.0  # um per voxel


def rd(t):
    h = pd.read_csv(f'{D}/{t}_header.csv', header=None)[0].tolist()
    d = pd.read_csv(f'{D}/{t}.csv.gz', header=None); d.columns = h; return d


ct = rd('aibs_metamodel_celltypes_v661_merged')
ct = ct[ct.cell_type.isin(TYPES)].drop_duplicates('target_id', keep=False)
nuc = rd('nucleus_detection_v0_merged')
pr = rd('proofreading_status_and_strategy_merged')
conn = pd.read_pickle(f'{D}/soma_soma_v1412.pkl')

# neuron table (post candidates): nucleus id, type, position (um)
neu = ct[['target_id', 'cell_type', 'pt_position_x', 'pt_position_y', 'pt_position_z']].rename(columns={'target_id': 'nuc_id'})
P = neu[['pt_position_x', 'pt_position_y', 'pt_position_z']].to_numpy() * VOX
neu['x'], neu['y'], neu['z'] = P[:, 0], P[:, 1], P[:, 2]
neu = neu.reset_index(drop=True)
# pia reference: 1st percentile of neuron soma depth (y increases with depth)
pia = np.percentile(neu.y, 0.5)
neu['depth'] = neu.y - pia
idx = {n: i for i, n in enumerate(neu.nuc_id)}

# proofread presynaptic neurons (single nucleus, axon proofread)
nroot = nuc.groupby('pt_root_id').id.agg(['count', 'first'])
pr = pr.merge(nroot, left_on='pt_root_id', right_index=True)
pr = pr[(pr['count'] == 1) & (pr.status_axon == 't')]
pre = neu[neu.nuc_id.isin(pr['first'])].merge(pr[['first', 'strategy_axon']], left_on='nuc_id', right_on='first').drop(columns='first')
pre.to_csv(f'{OUT}/pre_neurons.csv', index=False)
print('proofread presynaptic neurons by type:\n', pre.cell_type.value_counts())

c = conn[conn.pre_nuc_id.isin(pre.nuc_id) & conn.post_nuc_id.isin(neu.nuc_id)].copy()
c['post_i'] = c.post_nuc_id.map(idx)
c = c.merge(pre[['nuc_id', 'cell_type']].rename(columns={'nuc_id': 'pre_nuc_id', 'cell_type': 'pre_type'}), on='pre_nuc_id')
c['post_type'] = neu.cell_type.to_numpy()[c.post_i]
c['mean_size'] = c.sum_size / c.n_syn
c.drop(columns=['post_i']).to_csv(f'{OUT}/proofread_connections.csv.gz', index=False)
print('connections from proofread axons:', len(c), 'synapses:', int(c.n_syn.sum()))

LAT = np.array([0, 25, 50, 75, 100, 150, 200, 300, 400, 600, 1e9])
DEP = np.arange(-100, 1200, 25.0)
post_type_code = pd.Categorical(neu.cell_type, categories=TYPES).codes
X, Y, Z, DEPTH = neu.x.to_numpy(), neu.y.to_numpy(), neu.z.to_numpy(), neu.depth.to_numpy()
dbin = np.clip(np.digitize(DEPTH, DEP) - 1, 0, len(DEP) - 2)


def bins_for(i_pre, mode):
    r = pre.iloc[i_pre]
    lat = np.hypot(X - r.x, Z - r.z)
    lb = np.clip(np.digitize(lat, LAT) - 1, 0, len(LAT) - 2)
    if mode == 'abs_depth':
        db = dbin
    else:  # relative depth (post - pre)
        rel = DEPTH - r.depth
        db = np.clip(np.digitize(rel, np.arange(-1200, 1225, 25.0)) - 1, 0, 96)
    return lb * 200 + db


def run_null(mode='abs_depth', weight='n_syn', tag='main'):
    """Two-pass estimator: (1) per pre-type spatial rate r_a(bin) pooled over all post types;
    (2) per pre neuron expected synapses distributed over candidates proportional to r_a(bin), scaled
    to the neuron's observed total output (post-type-blind null)."""
    nb = 200 * 200
    num = {t: np.zeros(nb) for t in TYPES}; den = {t: np.zeros(nb) for t in TYPES}
    cache = []
    by_pre = {k: g for k, g in c.groupby('pre_nuc_id')}
    for i in range(len(pre)):
        r = pre.iloc[i]
        b = bins_for(i, mode)
        self_i = idx[r.nuc_id]
        cnt = np.bincount(np.delete(b, self_i), minlength=nb)
        g = by_pre.get(r.nuc_id)
        obs = np.zeros(len(neu))
        if g is not None:
            obs[g.post_i.to_numpy()] = (g.n_syn if weight == 'n_syn' else (g.n_syn > 0).astype(float)).to_numpy()
        obs[self_i] = 0
        s = np.bincount(b, weights=obs, minlength=nb)
        num[r.cell_type] += s; den[r.cell_type] += cnt
        cache.append((b, obs.sum(), self_i))
    rate = {t: np.divide(num[t], den[t], out=np.zeros(nb), where=den[t] > 0) for t in TYPES}
    E = np.zeros((len(pre), len(TYPES))); O = np.zeros((len(pre), len(TYPES)))
    for i in range(len(pre)):
        b, tot, self_i = cache[i]
        w = rate[pre.iloc[i].cell_type][b].copy(); w[self_i] = 0
        if w.sum() == 0 or tot == 0: continue
        e = tot * w / w.sum()
        E[i] = np.bincount(post_type_code, weights=e, minlength=len(TYPES))
    for t_i, t in enumerate(TYPES):
        pass
    agg = c.assign(v=(c.n_syn if weight == 'n_syn' else 1.0)).groupby(['pre_nuc_id', 'post_type']).v.sum().unstack(fill_value=0)
    agg = agg.reindex(index=pre.nuc_id, columns=TYPES, fill_value=0)
    O = agg.to_numpy(float)
    np.save(f'{OUT}/O_{tag}.npy', O); np.save(f'{OUT}/E_{tag}.npy', E)
    return O, E


def type_matrix(O, E, groups):
    Om = np.array([O[groups == t].sum(0) for t in TYPES]); Em = np.array([E[groups == t].sum(0) for t in TYPES])
    return Om, Em


def interaction(L, W=None):
    """Weighted double-centring of a log-ratio matrix (row/column main effects removed)."""
    W = np.ones_like(L) if W is None else W
    I = L.copy()
    for _ in range(50):
        I = I - (np.nansum(I * W, 1) / np.nansum(W, 1))[:, None]
        I = I - (np.nansum(I * W, 0) / np.nansum(W, 0))[None, :]
    return I


groups = pre.cell_type.to_numpy()
results = {}
for tag, mode, weight in [('main', 'abs_depth', 'n_syn'), ('reldepth', 'rel_depth', 'n_syn'), ('binary', 'abs_depth', 'binary')]:
    O, E = run_null(mode, weight, tag)
    Om, Em = type_matrix(O, E, groups)
    L = np.log2((Om + 0.5) / (Em + 0.5))
    results[tag] = (Om, Em, L, interaction(L, np.sqrt(Em)))
    print(tag, 'done')

# bootstrap over presynaptic neurons (within type) for main null
O, E = np.load(f'{OUT}/O_main.npy'), np.load(f'{OUT}/E_main.npy')
B = 1000; boots = np.zeros((B, len(TYPES), len(TYPES))); bootsI = np.zeros_like(boots)
gidx = {t: np.where(groups == t)[0] for t in TYPES}
for bi in range(B):
    Om = np.zeros((len(TYPES), len(TYPES))); Em = np.zeros_like(Om)
    for k, t in enumerate(TYPES):
        s = rng.choice(gidx[t], len(gidx[t]), replace=True)
        Om[k] = O[s].sum(0); Em[k] = E[s].sum(0)
    L = np.log2((Om + 0.5) / (Em + 0.5)); boots[bi] = L; bootsI[bi] = interaction(L, np.sqrt(Em))

# connection-level stability metrics (pruning-resistance proxies)
c['multi'] = (c.n_syn >= 2).astype(float)
st = c.groupby(['pre_type', 'post_type']).agg(n_conn=('n_syn', 'size'), n_syn=('n_syn', 'sum'), multi_frac=('multi', 'mean'),
                                               mean_log_size=('mean_size', lambda v: np.mean(np.log10(v))), syn_per_conn=('n_syn', 'mean')).reset_index()
rows = []
Om, Em, L, I = results['main']
for a_i, a in enumerate(TYPES):
    for b_i, b in enumerate(TYPES):
        rows.append(dict(pre_type=a, post_type=b, O=Om[a_i, b_i], E=Em[a_i, b_i], log2OE=L[a_i, b_i], interaction=I[a_i, b_i],
                         log2OE_lo=np.percentile(boots[:, a_i, b_i], 2.5), log2OE_hi=np.percentile(boots[:, a_i, b_i], 97.5),
                         inter_lo=np.percentile(bootsI[:, a_i, b_i], 2.5), inter_hi=np.percentile(bootsI[:, a_i, b_i], 97.5),
                         log2OE_reldepth=results['reldepth'][2][a_i, b_i], interaction_reldepth=results['reldepth'][3][a_i, b_i],
                         log2OE_binary=results['binary'][2][a_i, b_i], interaction_binary=results['binary'][3][a_i, b_i],
                         n_pre=int((groups == a).sum()), n_post=int((neu.cell_type == b).sum())))
tp = pd.DataFrame(rows).merge(st, on=['pre_type', 'post_type'], how='left')
tp.to_csv(f'{OUT}/type_pair_stats.csv', index=False)
np.save(f'{OUT}/boot_log2OE.npy', boots); np.save(f'{OUT}/boot_interaction.npy', bootsI)
neu.to_csv(f'{OUT}/neurons.csv', index=False)
print(tp.pivot(index='pre_type', columns='post_type', values='log2OE').reindex(index=TYPES, columns=TYPES).round(2))
