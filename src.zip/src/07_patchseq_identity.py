"""Assign Patch-seq BAM files (NeMO 'ar_<id>' names) to Patch-seq cells by read-count fingerprinting.

The NeMO alignment files are named by analysis-run identifiers that are not listed in the public metadata.
For each BAM we have uniquely-mapped read counts for ~55 adhesion genes (02_extract_splicing.py). We match
this vector to the released gene-count matrix (20200513_Mouse_PatchSeq_Release_count.v2) by Pearson
correlation of log counts; an assignment is accepted when r_best >= 0.85, r_best - r_second >= 0.05 and the best-matching sample
belongs to the sequencing tube recorded in the BAM header (independent check).
"""
import os as _os, sys as _sys
_sys.path.insert(0, _os.path.dirname(_os.path.abspath(__file__)) if 'src' in __file__ else _os.path.join(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))), 'src'))
from paths import ROOT, DATA, RES
import sys, json, glob, numpy as np, pandas as pd
JS, OUT = sys.argv[1], sys.argv[2]
D = f'{DATA}/patchseq'
recs = [json.loads(l) for l in open(JS)]
genes = sorted({g for r in recs for g in r['genes'] if g != 'PCDH_CLUSTER'})
f = glob.glob(f'{D}/20200513_Mouse_PatchSeq_Release_count.v2/*.csv')[0]
cnt = []
for ch in pd.read_csv(f, chunksize=3000, index_col=0):
    k = ch.loc[ch.index.isin(genes)]
    if len(k): cnt.append(k)
C = pd.concat(cnt)
genes = [g for g in genes if g in C.index]
Y = np.log1p(C.loc[genes].to_numpy(float)).T  # cells x genes
Yz = (Y - Y.mean(1, keepdims=True)) / (Y.std(1, keepdims=True) + 1e-9)
rows = []
for r in recs:
    x = np.log1p(np.array([r['genes'].get(g, 0) for g in genes], float))
    xz = (x - x.mean()) / (x.std() + 1e-9)
    cor = Yz @ xz / len(genes)
    o = np.argsort(cor)[::-1]
    tube = (r.get('fastq') or '').split('_E1-50')[0]
    same_tube = [i for i in o if C.columns[i].startswith(tube + '_')] if tube else []
    best_tube = C.columns[same_tube[0]] if same_tube else None
    rows.append(dict(bam_id=r['cell_id'], fastq=r.get('fastq'), tube=tube, sample_id=C.columns[o[0]], r_best=cor[o[0]], r_second=cor[o[1]],
                     best_in_tube=best_tube, tube_match=(best_tube == C.columns[o[0]])))
m = pd.DataFrame(rows)
m['accepted'] = (m.r_best >= 0.85) & (m.r_best - m.r_second >= 0.05) & m.tube_match
dup = m[m.accepted].sample_id.duplicated(keep=False)
m.loc[m.accepted & m.sample_id.isin(m[m.accepted][dup].sample_id), 'accepted'] = False
m.to_csv(OUT, index=False)
meta = pd.read_csv(f'{RES}/expression/patchseq_meta_used.csv')
a = m[m.accepted].merge(meta, left_on='sample_id', right_on='transcriptomics_sample_id')
a[['bam_id', 'sample_id', 'subclass', 'corresponding_AIT2.3.1_alias']].rename(columns={'bam_id': 'cell_id'}).to_csv(f'{RES}/splicing/patchseq_cells_meta.csv', index=False)
print(len(m), 'BAMs;', int(m.accepted.sum()), 'uniquely assigned;', 'median r_best', round(m.r_best.median(), 4), 'median margin', round((m.r_best - m.r_second).median(), 4))
