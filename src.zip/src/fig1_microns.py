"""Figure 1: study design and geometry-corrected type-to-type specificity in MICrONS."""
import os as _os, sys as _sys
_sys.path.insert(0, _os.path.dirname(_os.path.abspath(__file__)) if 'src' in __file__ else _os.path.join(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))), 'src'))
from paths import ROOT, DATA, RES
import numpy as np, pandas as pd, matplotlib.pyplot as plt, os, sys
from matplotlib.patches import FancyBboxPatch
sys.path.insert(0, os.path.dirname(__file__))
from fig_style import *
setup()
R = f'{RES}'; FD = f'{ROOT}/figures'; os.makedirs(FD, exist_ok=True)
tp = pd.read_csv(f'{R}/microns/type_pair_stats.csv')
M = lambda c: tp.pivot(index='pre_type', columns='post_type', values=c).reindex(index=TYPES, columns=TYPES).to_numpy()
L, I, lo, hi = M('log2OE'), M('interaction'), M('log2OE_lo'), M('log2OE_hi')
ilo, ihi = M('inter_lo'), M('inter_hi')

fig = plt.figure(figsize=(7.4, 4.5))
gs = fig.add_gridspec(2, 3, height_ratios=[0.62, 1.25], width_ratios=[1, 1, 0.72], hspace=0.25, wspace=0.75)

# a: schematic
ax = fig.add_subplot(gs[0, :]); ax.axis('off'); panel(ax, 'a', x=-0.02, y=0.98)
def box(x, y, w, h, t, fc):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle='round,pad=0.008,rounding_size=0.015', fc=fc, ec=INK2, lw=0.6, transform=ax.transAxes))
    ax.text(x + w / 2, y + h / 2, t, ha='center', va='center', fontsize=5.9, transform=ax.transAxes, color=INK)
def arr(x0, y0, x1, y1):
    ax.annotate('', xy=(x1, y1), xytext=(x0, y0), xycoords='axes fraction', arrowprops=dict(arrowstyle='-|>', lw=0.8, color=INK2))
box(0.01, 0.62, 0.20, 0.30, 'SMART-seq v4 (VISp) and\nPatch-seq alignments\n(unindexed BAMs, NeMO)', '#e8f1f8')
box(0.25, 0.62, 0.20, 0.30, 'Remote range-request\njunction extraction\n(adhesion genes, Pcdh)', '#e8f1f8')
box(0.50, 0.62, 0.20, 0.30, 'Type-level PSI of\nSS4, meA/meB, Ten insert;\nPcdh isoform usage', '#e8f1f8')
box(0.01, 0.08, 0.20, 0.30, 'MICrONS minnie65 v1412\n1,934 proofread axons\n72,150 typed neurons', '#fbeee6')
box(0.25, 0.08, 0.20, 0.30, 'Geometric (Peters-rule)\nnull: lateral distance x\ndepth, per pre-type', '#fbeee6')
box(0.50, 0.08, 0.20, 0.30, 'Specificity log2(O/E)\nand double-centred\ninteraction term', '#fbeee6')
box(0.76, 0.27, 0.23, 0.48, 'Isoform-gated\nadhesion code C$_k$(a,b)\nvs connectivity;\ncross-validated,\nnull-calibrated', '#eef6ee')
for y in (0.77, 0.23):
    arr(0.20, y, 0.25, y); arr(0.45, y, 0.50, y)
arr(0.70, 0.77, 0.76, 0.60); arr(0.70, 0.23, 0.76, 0.42)
ax.text(0.35, 0.5, 'shared type key: L2/3 IT↔23P, L4↔4P, L5 IT↔5P-IT, L5 PT↔5P-ET, NP↔5P-NP, L6 IT↔6P-IT, L6 CT↔6P-CT,\nPvalb↔BC, Sst↔MC, Vip↔BPC, Lamp5↔NGC', ha='center', va='center', fontsize=5.8, color=INK2, transform=ax.transAxes)

def heat(ax, Z, sig, title, vmax, letter):
    im = ax.imshow(Z, cmap=DIV, vmin=-vmax, vmax=vmax)
    ax.set_xticks(range(11)); ax.set_xticklabels(TYPES, rotation=90); ax.set_yticks(range(11)); ax.set_yticklabels(TYPES)
    ax.set_xlabel('Postsynaptic type'); ax.set_ylabel('Presynaptic type'); ax.set_title(title, loc='left')
    for i in range(11):
        for j in range(11):
            if sig[i, j]: ax.plot(j, i, 'o', ms=1.8, color=INK, mec='none')
    ax.axhline(6.5, color=INK2, lw=0.6); ax.axvline(6.5, color=INK2, lw=0.6)
    ax.spines[:].set_visible(False); panel(ax, letter, x=-0.32)
    return im
ax = fig.add_subplot(gs[1, 0]); im = heat(ax, L, (lo > 0) | (hi < 0), 'Specificity, log$_2$(O/E)', 3, 'b')
cb = fig.colorbar(im, ax=ax, fraction=0.045, pad=0.03); cb.outline.set_visible(False)
ax = fig.add_subplot(gs[1, 1]); im = heat(ax, I, (ilo > 0) | (ihi < 0), 'Interaction (main effects removed)', 2, 'c')
cb = fig.colorbar(im, ax=ax, fraction=0.045, pad=0.03); cb.outline.set_visible(False)

ax = fig.add_subplot(gs[1, 2]); panel(ax, 'd', x=-0.42)
x, y = tp.interaction, tp.interaction_reldepth
ax.scatter(x, y, s=8, color=CAT[0], alpha=0.8, lw=0)
ax.scatter(tp.interaction, tp.interaction_binary, s=8, color=CAT[1], alpha=0.8, lw=0, marker='^')
from scipy.stats import spearmanr
r1 = spearmanr(x, y)[0]; r2 = spearmanr(tp.interaction, tp.interaction_binary)[0]
ax.plot([-3, 3], [-3, 3], color=GRID, lw=0.8, zorder=0)
ax.set_xlabel('Interaction (main null)'); ax.set_ylabel('Interaction (alternative)')
ax.text(0.03, 0.97, f'rel.-depth null ρ={r1:.2f}', color=CAT[0], transform=ax.transAxes, va='top', ha='left', fontsize=5.8)
ax.text(0.03, 0.88, f'binary ρ={r2:.2f}', color=CAT[1], transform=ax.transAxes, va='top', ha='left', fontsize=5.8)
ax.set_xlim(-2.5, 2.5); ax.set_ylim(-2.5, 2.5); ax.set_aspect('equal')
save(fig, f'{FD}/Figure1')
print('ok')
