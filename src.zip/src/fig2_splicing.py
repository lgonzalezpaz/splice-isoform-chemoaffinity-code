"""Figure 2: cell-type-specific splicing of synaptic adhesion genes (SMART-seq v4, VISp) and Patch-seq replication."""
import os as _os, sys as _sys
_sys.path.insert(0, _os.path.dirname(_os.path.abspath(__file__)) if 'src' in __file__ else _os.path.join(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))), 'src'))
from paths import ROOT, DATA, RES
import numpy as np, pandas as pd, matplotlib.pyplot as plt, os, sys, json
from scipy import stats
sys.path.insert(0, os.path.dirname(__file__))
from fig_style import *
setup()
R = f'{RES}'; FD = f'{ROOT}/figures'
S = ['L2/3 IT', 'L4', 'L5 IT', 'L5 PT', 'NP', 'L6 IT', 'L6 CT', 'L6b', 'Pvalb', 'Sst', 'Vip', 'Lamp5', 'Sncg']
ev = pd.read_csv(f'{R}/splicing/tasic_events.csv')
key = pd.read_csv(f'{R}/splicing/key_events.csv')
ps = pd.read_csv(f'{R}/splicing/patchseq_events.csv') if os.path.exists(f'{R}/splicing/patchseq_events.csv') else None
ml = pd.read_csv(f'{R}/expression/tasic_meanlog.csv', index_col=0)
stats_out = {}

fig = plt.figure(figsize=(7.4, 7.6))
gs = fig.add_gridspec(3, 3, height_ratios=[1, 1.05, 0.95], hspace=0.62, wspace=0.55)

# a: landscape
ax = fig.add_subplot(gs[0, 0]); panel(ax, 'a', x=-0.3)
alt = ev[ev.alternative & ev.q.notna()].copy()
alt['exonkey'] = alt.gene + ':' + alt.exon
alt = alt.sort_values('q').drop_duplicates('exonkey')
sig = alt.q < 0.05
ax.scatter(alt.psi_range[~sig], -np.log10(alt.p[~sig]), s=5, color='#bdbdbd', lw=0, label='n.s.')
ax.scatter(alt.psi_range[sig], -np.log10(alt.p[sig]), s=7, color=CAT[0], lw=0, label='FDR < 0.05')
ax.set_xlabel('ΔPSI range across subclasses'); ax.set_ylabel('−log$_{10}$ P (permutation)')
ax.set_title('Alternative adhesion exons', loc='left')
ax.legend(frameon=False, loc='center right', handletextpad=0.2)
stats_out['n_alt_exons'] = int(len(alt)); stats_out['n_sig_exons'] = int(sig.sum()); stats_out['n_sig_genes'] = int(alt[sig].gene.nunique())
stats_out['sig_genes'] = sorted(alt[sig].gene.unique().tolist())

# b: heatmap of significant events
ax = fig.add_subplot(gs[0, 1:]); panel(ax, 'b', x=-0.12)
top = alt[sig].copy()
P = top[[f'psi|{s}' for s in S]].to_numpy()
ok = np.isfinite(P).sum(1) >= 11; top = top[ok]; P = P[ok]
Pf = np.where(np.isnan(P), np.nanmean(P, 1, keepdims=True), P)
from scipy.cluster.hierarchy import linkage, leaves_list
o = leaves_list(linkage(Pf, 'average', metric='correlation')) if len(Pf) > 2 else np.arange(len(Pf))
im = ax.imshow(P[o].T, aspect='auto', cmap=SEQ, vmin=0, vmax=1, interpolation='nearest')
ax.set_yticks(range(len(S))); ax.set_yticklabels(S)
lab = (top.gene + ' ' + top.length.astype(str) + 'nt').to_numpy()[o]
ax.set_xticks(range(len(lab))); ax.set_xticklabels(lab, rotation=90, fontsize=4.6)
ax.axhline(7.5, color=INK, lw=0.6); ax.spines[:].set_visible(False)
ax.set_title(f'PSI of {len(top)} type-dependent exons (FDR < 0.05)', loc='left')
cb = fig.colorbar(im, ax=ax, fraction=0.02, pad=0.01); cb.set_label('PSI'); cb.outline.set_visible(False)

# c: key events with CIs; Patch-seq overlay
def key_row(rule, gene):
    k = key[(key.rule == rule) & (key.gene == gene)].iloc[0]
    return ev.set_index('event').loc[k.event], k.event
show = [('SS4', 'Nrxn1', 'Nrxn1 SS4'), ('SS4', 'Nrxn2', 'Nrxn2 SS4'), ('SS4', 'Nrxn3', 'Nrxn3 SS4'), ('MEB', 'Ptprs', 'Ptprs meB'), ('MEA', 'Ptprd', 'Ptprd meA')]
ax = fig.add_subplot(gs[1, :2]); panel(ax, 'c', x=-0.08)
xs = np.arange(len(S))
for i, (rule, gene, nm) in enumerate(show):
    if rule == 'MEA':
        kk = key[(key.rule == 'MEA') & (key.gene == 'Ptprd') & (key.length == 18)].iloc[0]
        r = ev.set_index('event').loc[kk.event]; eid = kk.event
    else:
        r, eid = key_row(rule, gene)
    y = np.array([r[f'psi|{s}'] for s in S], float)
    lo = np.array([r.get(f'lo|{s}', np.nan) for s in S], float); hi = np.array([r.get(f'hi|{s}', np.nan) for s in S], float)
    off = (i - 2) * 0.13
    ax.errorbar(xs + off, y, yerr=[y - lo, hi - y], fmt='o', ms=3, color=CAT[i], lw=0.8, capsize=0, label=nm)
    if ps is not None and eid in set(ps.event):
        q = ps.set_index('event').loc[eid]
        yp = np.array([q.get(f'psi|{s}', np.nan) for s in S], float)
        ax.scatter(xs + off, yp, s=12, facecolor='none', edgecolor=CAT[i], lw=0.7, marker='D')
ax.set_xticks(xs); ax.set_xticklabels(S, rotation=45, ha='right'); ax.set_ylabel('PSI (95% CI)'); ax.set_ylim(-0.05, 1.05)
ax.axvline(7.5, color=GRID, lw=0.8)
ax.scatter([], [], s=12, facecolor='none', edgecolor=INK2, marker='D', label='Patch-seq')
ax.legend(frameon=False, ncol=6, loc='upper center', bbox_to_anchor=(0.5, 1.2), columnspacing=0.8, handletextpad=0.2)

# d: SLM2 (Khdrbs3) vs SS4
ax = fig.add_subplot(gs[1, 2]); panel(ax, 'd', x=-0.3)
r1, _ = key_row('SS4', 'Nrxn1')
p1 = np.array([r1[f'psi|{s}'] for s in S], float); xk = ml.loc['Khdrbs3', S].to_numpy()
rho, pv = stats.spearmanr(xk, p1)
perm = np.array([stats.spearmanr(xk, np.random.default_rng(i).permutation(p1))[0] for i in range(10000)])
pp = (1 + np.sum(np.abs(perm) >= abs(rho))) / 10001
stats_out['SLM2_vs_Nrxn1SS4'] = dict(rho=float(rho), p_perm=float(pp))
for g in ['Nrxn2', 'Nrxn3']:
    rr, _ = key_row('SS4', g); pg = np.array([rr[f'psi|{s}'] for s in S], float)
    stats_out[f'SLM2_vs_{g}SS4'] = dict(rho=float(stats.spearmanr(xk, pg)[0]))
cols = [CAT[0] if i < 8 else CAT[1] for i in range(len(S))]
ax.scatter(xk, p1, s=14, c=cols, lw=0)
for i, s in enumerate(S):
    if s in ('NP', 'Sncg', 'L4', 'Pvalb', 'L6 CT', 'Lamp5'):
        ax.annotate(s, (xk[i], p1[i]), xytext=(3, 2), textcoords='offset points', fontsize=5.3, color=INK2)
ax.set_xlabel('Khdrbs3 (SLM2), log$_2$(CPM+1)'); ax.set_ylabel('Nrxn1 SS4 PSI')
ax.text(0.03, 0.04, f'ρ = {rho:.2f}, P$_{{perm}}$ = {pp:.1e}', transform=ax.transAxes, fontsize=6)
ax.text(0.03, 0.22, 'glutamatergic', color=CAT[0], transform=ax.transAxes, ha='left', fontsize=5.8)
ax.text(0.03, 0.14, 'GABAergic', color=CAT[1], transform=ax.transAxes, ha='left', fontsize=5.8)

# e: clustered Pcdh isoform usage
ax = fig.add_subplot(gs[2, :2]); panel(ax, 'e', x=-0.08)
pc = pd.read_csv(f'{R}/splicing/tasic_events_pcdh.csv', index_col=0)
cols_p = [c for c in pc.columns if c.startswith('Pcdh')]
order = sorted(cols_p, key=lambda c: (c[4], {'a': 0, 'b': 1, 'g': 2}[c[4]], int(''.join(ch for ch in c if ch.isdigit()) or 0), c))
order = [c for c in json.load(open(f'{ROOT}/data_ref/adhesion_annotation_vM25.json'))['pcdh'] if c in cols_p]
X = pc[order].to_numpy(float); tot = X.sum(1); keep = tot >= 10
frac = X[keep] / tot[keep, None]; labs = pc.subclass.to_numpy()[keep]
M = np.array([frac[labs == s].mean(0) for s in S])
im = ax.imshow(M, aspect='auto', cmap=SEQ, vmin=0, vmax=np.percentile(M, 99))
ax.set_yticks(range(len(S))); ax.set_yticklabels(S); ax.set_xticks(range(len(order)))
ax.set_xticklabels([c.replace('Pcdh', '') for c in order], rotation=90, fontsize=4.6)
ax.axhline(7.5, color=INK, lw=0.6); ax.spines[:].set_visible(False)
ax.set_title('Clustered Pcdh variable-exon usage (fraction)', loc='left')
cb = fig.colorbar(im, ax=ax, fraction=0.02, pad=0.01); cb.outline.set_visible(False)
stats_out['pcdh_cells'] = int(keep.sum())
cstr = M[:, [i for i, c in enumerate(order) if c in ('Pcdhac2', 'Pcdhgc3', 'Pcdhgc4', 'Pcdhgc5')]].sum(1)
stats_out['pcdh_ctype_fraction_by_subclass'] = dict(zip(S, np.round(cstr, 3).tolist()))

# f: within- vs between-cell isoform similarity
ax = fig.add_subplot(gs[2, 2]); panel(ax, 'f', x=-0.3)
Xn = frac / np.linalg.norm(frac, axis=1, keepdims=True)
rng = np.random.default_rng(0); same, diff = [], []
for _ in range(20000):
    i, j = rng.integers(0, len(Xn), 2)
    if i == j: continue
    (same if labs[i] == labs[j] else diff).append(Xn[i] @ Xn[j])
ax.hist(diff, bins=40, range=(0, 1), density=True, color='#bdbdbd', label='different subclass')
ax.hist(same, bins=40, range=(0, 1), density=True, histtype='step', color=CAT[0], lw=1.2, label='same subclass')
ax.set_xlabel('Cell-pair cosine similarity'); ax.set_ylabel('Density'); ax.legend(frameon=False, fontsize=5.5)
u = stats.mannwhitneyu(same, diff)
stats_out['pcdh_same_vs_diff'] = dict(median_same=float(np.median(same)), median_diff=float(np.median(diff)), p=float(u.pvalue))
save(fig, f'{FD}/Figure2')
json.dump(stats_out, open(f'{R}/splicing/figure2_stats.json', 'w'), indent=1)
print(json.dumps(stats_out, indent=1))
