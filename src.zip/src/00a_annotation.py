"""Extract gene bodies and cassette exons for target adhesion genes from GENCODE vM25 (GRCm38/mm10)."""
import gzip, re, json, sys, collections
GTF = sys.argv[1]; OUT = sys.argv[2]
SPLICE_GENES = ["Nrxn1","Nrxn2","Nrxn3","Nlgn1","Nlgn2","Nlgn3","Ptprd","Ptprs","Ptprf",
  "Tenm1","Tenm2","Tenm3","Tenm4","Adgrl1","Adgrl2","Adgrl3","Dscam","Dscaml1","Sdk1","Sdk2",
  "Il1rapl1","Il1rap","Clstn1","Clstn2","Clstn3","Cadm1","Cadm2","Cadm3","Kirrel3","Nrcam","Nfasc","L1cam",
  "Lrrtm1","Lrrtm2","Lrrtm3","Lrrtm4","Cbln1","Cbln2","Cbln4","Grid1","Grid2","Dag1","Slitrk1","Slitrk3","Slitrk5",
  "Elfn1","Grm7","Flrt2","Flrt3","Unc5c","Cntnap2","Cntn5"]
pcdh_ex = {}
genes = {}; tx_exons = collections.defaultdict(list); tx_gene = {}
with gzip.open(GTF,'rt') as f:
    for line in f:
        if line[0]=='#': continue
        c=line.rstrip('\n').split('\t')
        if c[2] not in ('gene','exon'): continue
        gn=re.search('gene_name "([^"]+)"',c[8]).group(1)
        ispcdh = re.match(r'Pcdh[abg]', gn) is not None
        if gn not in SPLICE_GENES and not ispcdh: continue
        gt=re.search('gene_type "([^"]+)"',c[8]).group(1)
        if c[2]=='gene':
            genes[gn]=dict(chrom=c[0],start=int(c[3]),end=int(c[4]),strand=c[6],type=gt)
        else:
            if ispcdh:
                pcdh_ex.setdefault(gn,[]).append((int(c[3]),int(c[4])))
            tt=re.search('transcript_type "([^"]+)"',c[8]).group(1)
            if tt!='protein_coding': continue
            tid=re.search('transcript_id "([^"]+)"',c[8]).group(1)
            tx_exons[tid].append((int(c[3]),int(c[4]))); tx_gene[tid]=gn
# cassette exons: internal exons in >=1 transcript whose flanking-intron pair is spanned by an intron in another transcript
introns=collections.defaultdict(set); internal=collections.defaultdict(dict)
for tid,ex in tx_exons.items():
    ex=sorted(ex); g=tx_gene[tid]
    for i in range(len(ex)-1): introns[g].add((ex[i][1],ex[i+1][0]))
    for i in range(1,len(ex)-1): internal[g][(ex[i][0],ex[i][1])]=(ex[i-1][1],ex[i+1][0])
cassettes=[]
for g,d in internal.items():
    for (s,e),(up,dn) in d.items():
        # inclusion junctions up->s and e->dn ; skipping junction up->dn must exist in annotation
        if (up,dn) in introns[g]:
            cassettes.append(dict(gene=g,chrom=genes[g]['chrom'],strand=genes[g]['strand'],exon_start=s,exon_end=e,
                                  length=e-s+1,up_donor=up,dn_acceptor=dn))
# dedupe
seen=set(); cas=[]
for c in cassettes:
    k=(c['gene'],c['exon_start'],c['exon_end'],c['up_donor'],c['dn_acceptor'])
    if k not in seen: seen.add(k); cas.append(c)
# Pcdh variable exons: first exons of Pcdha/b/g single-gene entries (each variable exon is its own gene in GENCODE)
pcdh={}
for g,v in genes.items():
    if not re.match(r'Pcdh[abg]',g) or v['type']!='protein_coding': continue
    ex=sorted(set(pcdh_ex.get(g,[])))
    first = min(ex) if v['strand']=='+' else max(ex,key=lambda x:x[1])
    if g.startswith('Pcdhb'): first = max(ex, key=lambda x: x[1]-x[0])  # beta genes are single large exons
    pcdh[g]=dict(v, var_exon=list(first), var_len=first[1]-first[0]+1)
json.dump(dict(genes=genes,cassettes=cas,pcdh=pcdh),open(OUT,'w'),indent=1)
print(len(genes),'genes;',len(cas),'cassette events;',len(pcdh),'Pcdh cluster genes')
for g in ["Nrxn1","Nrxn2","Nrxn3","Nlgn1","Ptprd","Tenm3"]:
    print(g,genes.get(g),[ (c['exon_start'],c['length']) for c in cas if c['gene']==g][:30])
