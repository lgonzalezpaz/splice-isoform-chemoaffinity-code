"""Build manuscript tables (JSON for the DOCX builder and CSV for the repository)."""
import os as _os, sys as _sys
_sys.path.insert(0, _os.path.dirname(_os.path.abspath(__file__)) if 'src' in __file__ else _os.path.join(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))), 'src'))
from paths import ROOT, DATA, RES
import json, glob, os, numpy as np, pandas as pd
R = f'{RES}'; OUT = f'{ROOT}/manuscript'
S = ['L2/3 IT', 'L4', 'L5 IT', 'L5 PT', 'NP', 'L6 IT', 'L6 CT', 'L6b', 'Pvalb', 'Sst', 'Vip', 'Lamp5', 'Sncg']
E_, I_ = S[:8], S[8:]
tables = {}

# Table 1: data and parameters
pre = pd.read_csv(f'{R}/microns/pre_neurons.csv'); neu = pd.read_csv(f'{R}/microns/neurons.csv')
t1 = [
 ['Connectome', 'MICrONS minnie65, static materialization v1412', 'MICrONS Consortium 2025'],
 ['Cell types', 'aibs_metamodel_celltypes_v661; 11 neuronal types', 'Elabbady et al. 2025'],
 ['Presynaptic neurons', f'{len(pre):,} with proofread axon, single nucleus', 'proofreading_status_and_strategy'],
 ['Postsynaptic neurons', f'{len(neu):,} typed neurons', 'this study'],
 ['Connections / synapses', '780,552 / 1,162,438 (from proofread axons)', 'connections_with_nuclei v1412'],
 ['Geometric bins', 'lateral distance 0,25,50,75,100,150,200,300,400,600,>600 µm × depth 25 µm', 'this study'],
 ['Pseudocount; weights', '0.5 synapses; w = √E', 'equations 3–4'],
 ['Bootstrap / split-half', '1,000 resamples; 200 split-halves of presynaptic neurons', 'this study'],
 ['Type key (MICrONS ↔ subclass)', '23P↔L2/3 IT; 4P↔L4; 5P-IT↔L5 IT; 5P-ET↔L5 PT; 5P-NP↔NP; 6P-IT↔L6 IT; 6P-CT↔L6 CT; BC↔Pvalb; MC↔Sst; BPC↔Vip; NGC↔Lamp5', 'Gouwens 2020; Elabbady 2025; Gamlin 2025'],
 ['Alternative type keys', 'NGC↔Sncg; 6P-CT↔L6b', 'sensitivity'],
 ['SMART-seq v4 (VISp)', '12,786 neurons (expression); 1,543 (junctions; ≤120 per subclass)', 'Tasic et al. 2018; GSE115746'],
 ['Patch-seq (VISp)', '4,221 interneurons (expression); 1,697 assigned files, 1,605 used (junctions)', 'Gouwens et al. 2020; NeMO'],
 ['Alignment / annotation', 'STAR 2.5.3a, GRCm38 (RefSeq accessions); GENCODE vM25', 'Allen Institute; Frankish 2019'],
 ['Read filter', 'MAPQ = 255 (unique); fragments deduplicated by read name', 'this study'],
 ['Event definition', 'junction support ≥3; cassette exon ≤500 nt; alternative site ≤60 nt', 'this study'],
 ['Event testing', '≥30 informative fragments; alternative if 0.05 < Ψ < 0.95 with ≥20 fragments; 2,000 label permutations; BH-FDR', 'equation 7'],
 ['Interactions', '32 curated (24 heterophilic, 12 splice-gated; 8 homophilic families)', 'Supplementary Table 1'],
 ['Bilinear model', 'ridge, λ = 10; leave-one-pair-out (exact) and leave-one-type-out', 'equations 11–12'],
 ['Null models', '10,000 / 2,000 / 300 type-label permutations; 1,000 random gene-pair sets; 1,000 Ψ permutations', 'Table 3'],
 ['Power simulation', '100 synthetic outcomes per effect size; 100 Ψ permutations', 'this study'],
]
tables['Table 1'] = dict(caption='Table 1 | Data sources, parameters and settings.', header=['Item', 'Value', 'Source'], rows=t1, widths=[2300, 5000, 2060])

# Table 2: key splice inserts
ev = pd.read_csv(f'{R}/splicing/tasic_events.csv').set_index('event')
ps = pd.read_csv(f'{R}/splicing/patchseq_events.csv').set_index('event')
key = pd.read_csv(f'{R}/splicing/key_events.csv')
cons = {'SS4': 'SS4⁻ only: LRRTM1/2, latrophilin-1; SS4⁺ only: cerebellin–GluD; modulates neuroligin-1, dystroglycan',
        'MEA': 'meA⁺ required for IL1RAPL1 binding (PTPδ)', 'MEB': 'meB⁺ required for Slitrk binding',
        'TENM': 'insert abolishes latrophilin binding'}
rows = []
for _, k in key.iterrows():
    r = ev.loc[k.event]
    ge = [r[f'psi|{s}'] for s in E_ if np.isfinite(r[f'psi|{s}']) and r[f'n|{s}'] >= 20]
    gi = [r[f'psi|{s}'] for s in I_ if np.isfinite(r[f'psi|{s}']) and r[f'n|{s}'] >= 20]
    pi = []
    if k.event in ps.index:
        q = ps.loc[k.event]; pi = [q[f'psi|{s}'] for s in I_ if f'psi|{s}' in q and np.isfinite(q[f'psi|{s}']) and q[f'n|{s}'] >= 20]
    fmt = lambda v: f'{min(v):.2f}–{max(v):.2f}' if len(v) else 'n.d.'
    exon = k.event.split(':')[2].split('@')[0]
    chrom = json.load(open(f'{ROOT}/data_ref/adhesion_annotation_vM25.json'))['genes'][k.gene]['chrom']
    qv = r['q'] if 'q' in r and np.isfinite(r['q']) else np.nan
    rows.append([{'SS4': 'SS4', 'MEA': 'meA', 'MEB': 'meB', 'TENM': 'Ten insert'}[k.rule], f'*{k.gene}*', f'{chrom}:{exon}', str(int(k.length)),
                 cons[k.rule], fmt(ge), fmt(gi), fmt(pi), ('<0.005' if qv < 0.005 else f'{qv:.2f}') if np.isfinite(qv) else 'n.t.',
                 str(int(r.n_inc + r.n_exc))])
order = {'SS4': 0, 'meA': 1, 'meB': 2, 'Ten insert': 3}
rows = sorted(rows, key=lambda r: (r[1].strip('*')[:4] != 'Nrxn', r[1], order[r[0]], int(r[3])))
tables['Table 2'] = dict(caption='Table 2 | Literature-defined ligand-switching inserts identified among de novo events. Ψ ranges are across glutamatergic (8) and GABAergic (5) subclasses with ≥20 informative fragments; n.d., not determined (insufficient reads); n.t., not tested (not alternative in any subclass). q, permutation FDR for type dependence (resolution limited by 2,000 permutations).',
                         header=['Insert', 'Gene', 'Exon (mm10)', 'nt', 'Binding consequence', 'Ψ glut.', 'Ψ GABA', 'Ψ GABA (Patch-seq)', 'q', 'Fragments'],
                         rows=rows, widths=[620, 700, 1650, 380, 2350, 800, 800, 900, 560, 600])

# Table 3: tests
S0 = json.load(open(f'{R}/code/summary.json'))
sens = {os.path.basename(os.path.dirname(p)).replace('code_sens_', ''): json.load(open(p)) for p in glob.glob(f'{R}/code_sens_*/summary.json')}
def rng_(f):
    v = [f(d) for d in sens.values()]
    v = [x for x in v if x is not None and np.isfinite(x)]
    return f'{min(v):.2f} to {max(v):.2f}' if v else '—'
t3 = [
 ['T1', 'Single interactions vs interaction term', '5/32 at q < 0.05 (gene-level); 4 negative (ρ −0.27 to −0.39), Nrxn–Clstn3 ρ = 0.26', 'Mantel-type label permutation, BH-FDR', '—', 'Associations reflect class co-expression'],
 ['T1', 'Adhesion compatibility index (equal weights)', f"ρ = {S0['ACI_iso']['rho']:.2f}", f"P = {S0['ACI_iso']['p_perm']:.3f}", rng_(lambda d: d['ACI_iso']['rho']), 'Opposite to predicted sign'],
 ['T2', 'Bilinear model, gene-level (LOO ρ)', f"{S0['T2']['pair_blind']:.2f}", '—', rng_(lambda d: d['T2']['pair_blind']), 'Predictive, ≈60% of noise ceiling'],
 ['T2', 'Bilinear model, isoform-gated (LOO ρ)', f"{S0['T2']['pair_iso']:.2f}", f"label perm. P = {S0['T2']['pair_iso_p_perm']:.3f}; random genes P = {S0['T2']['p_random_genes']:.2f}", rng_(lambda d: d['T2']['pair_iso']), 'Not better than random genes'],
 ['T2', 'Leave-one-type-out ρ (gene / isoform)', f"{S0['T2']['type_blind']:.2f} / {S0['T2']['type_iso']:.2f}", '—', '—', 'Generalises to unseen types'],
 ['T3', 'Isoform contribution Δρ', f"{S0['T3']['delta_cv_rho']:.2f} (95% CI {S0['T3']['delta_ci95'][0]:.2f} to {S0['T3']['delta_ci95'][1]:.2f})", f"Ψ-permutation P = {S0['T3']['p_psi_perm']:.2f}", rng_(lambda d: d['T3']['delta_cv_rho']), 'No detectable isoform information'],
 ['T3b', 'Rule-level Δρ (SS4; Ten insert)', f"{S0['T3b']['SS4']['mean_delta_rho']:.2f}; {S0['T3b']['TENM']['mean_delta_rho']:.2f}", f"P = {S0['T3b']['SS4']['p_one_sided']:.2f}; {S0['T3b']['TENM']['p_one_sided']:.2f} (one-sided)", '—', 'No rule-specific gain'],
 ['T4', 'Clustered-Pcdh similarity', f"ρ = {S0['T4_pcdh']['rho']:.2f}", f"P = {S0['T4_pcdh']['p_perm']:.3f}", rng_(lambda d: d['T4_pcdh']['rho']), 'Negative as predicted, but see T6'],
 ['T6', 'Pcdh partial | transcriptome', f"ρ = {S0['T6']['pcdh_partial_given_generic'][0]:.2f}", f"P = {S0['T6']['pcdh_partial_given_generic'][1]:.2f}", rng_(lambda d: d['T6']['pcdh_partial_given_generic'][0]), 'Explained by transcriptomic dissimilarity'],
 ['T6', 'Class-block model (weighted R²)', f"{S0['T6']['classblock_R2_weighted']:.2f}", '—', '—', 'Heterophilic E/I structure'],
 ['T5', 'Multisynaptic fraction, partial | interaction', f"ρ = {S0['T5']['multi_frac']['partial_rho_given_interaction']:.2f}", f"P = {S0['T5']['multi_frac']['partial_p']:.2f}", '—', 'Consolidation not predicted'],
 ['T5', 'Mean cleft size, partial | interaction', f"ρ = {S0['T5']['mean_log_size']['partial_rho_given_interaction']:.2f}", f"P = {S0['T5']['mean_log_size']['partial_p']:.3f}", '—', 'Weak, opposite sign'],
 ['T7', 'Noise ceiling (Spearman–Brown)', f"{S0['T7_noise_ceiling']['spearman_brown']:.2f}", f"split-half ρ = {S0['T7_noise_ceiling']['split_half_rho']:.2f}", '—', 'Upper bound on explainable signal'],
 ['T8', 'Power of T3 at ρ = 0.5 / 0.7 / 0.9', ' / '.join(f"{S0['T8_power'][k]:.2f}" for k in ['0.5', '0.7', '0.9']), 'α = 0.05; 100 simulations', '—', 'Only strong isoform codes excluded'],
]
tables['Table 3'] = dict(caption=f'Table 3 | Pre-specified tests and their outcomes. Sensitivity range spans {len(sens)} alternative analyses (Patch-seq interneuron expression, two alternative type keys, relative-depth null, binary connectivity, absolute splice rules only). LOO, leave-one-pair-out cross-validation.',
                         header=['Test', 'Quantity', 'Main estimate', 'Null / P', 'Sensitivity range', 'Interpretation'], rows=t3, widths=[520, 2300, 2050, 1950, 1150, 1390])
json.dump(tables, open(f'{OUT}/tables.json', 'w'), indent=1, ensure_ascii=False)
for k, v in tables.items():
    pd.DataFrame(v['rows'], columns=v['header']).to_csv(f'{RES}/{k.replace(" ", "")}.csv', index=False)
print(json.dumps(tables['Table 2']['rows'], ensure_ascii=False, indent=0)[:3000])
