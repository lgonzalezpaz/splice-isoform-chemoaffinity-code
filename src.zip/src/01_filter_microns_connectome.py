"""Filter the MICrONS v1412 soma-to-soma connection table to pairs with nuclei on both sides (streaming, chunked)."""
import os, sys, time, pandas as pd
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from paths import DATA
D = f'{DATA}/microns'
h = pd.read_csv(f'{D}/connections_with_nuclei_header.csv', header=None)[0].tolist()
out = []; n = 0; t = time.time()
for ch in pd.read_csv(f'{D}/connections_with_nuclei.csv.gz', header=None, names=h, chunksize=5_000_000,
                      dtype={'pre_pt_root_id': 'int64', 'post_pt_root_id': 'int64', 'n_syn': 'int32', 'sum_size': 'float64',
                             'pre_nuc_id': 'int64', 'post_nuc_id': 'int64'}):
    n += len(ch)
    out.append(ch[(ch.pre_nuc_id > 0) & (ch.post_nuc_id > 0) & (ch.pre_nuc_id != ch.post_nuc_id)])
    print(n, sum(len(o) for o in out), round(time.time() - t), flush=True)
d = pd.concat(out); d.to_pickle(f'{D}/soma_soma_v1412.pkl'); print('done', d.shape)
