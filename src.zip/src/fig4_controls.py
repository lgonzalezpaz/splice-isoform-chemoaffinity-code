"""Figure 4: specificity tracks transcriptomic dissimilarity and synaptic consolidation, robustly across analysis choices."""
import os as _os, sys as _sys
_sys.path.insert(0, _os.path.dirname(_os.path.abspath(__file__)) if 'src' in __file__ else _os.path.join(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))), 'src'))
from paths import ROOT, DATA, RES
import numpy as np, pandas as pd, matplotlib.pyplot as plt, os, sys, json, glob
from scipy import stats
sys.path.insert(0, os.path.dirname(__file__))
from fig_style import *
setup()
R = f'{RES}'; C = f'{R}/code'; FD = f'{ROOT}/figures'
S = json.load(open(f'{C}/summary.json'))
tp = pd.read_csv(f'{R}/microns/type_pair_stats.csv')
M = lambda c: tp.pivot(index='pre_type', columns='post_type', values=c).reindex(index=TYPES, columns=TYPES).to_numpy()
I = M('interaction'); W = np.sqrt(M('E')); y = I.ravel()


def dcenter(X, W):
    Z = X.copy()
    for _ in range(60):
        Z = Z - (np.nansum(Z * W, 1) / np.nansum(W, 1))[:, None]; Z = Z - (np.nansum(Z * W, 0) / np.nansum(W, 0))[None, :]
    return Z


cls = np.array([0] * 7 + [1] * 4); A = np.repeat(cls, 11); B = np.tile(cls, 11)
grp = {(0, 0): 'E→E', (0, 1): 'E→I', (1, 0): 'I→E', (1, 1): 'I→I'}
def sc(ax, x, yv, xl, yl, txt, top=False):
    for k_, (a, b) in enumerate(grp):
        m = (A == a) & (B == b); ax.scatter(x[m], yv[m], s=8, color=CAT[k_], lw=0, label=grp[(a, b)])
    ax.set_xlabel(xl); ax.set_ylabel(yl)
    if top: ax.text(0.03, 0.97, txt, transform=ax.transAxes, ha='left', va='top', fontsize=5.5)
    else: ax.text(0.97, 0.03, txt, transform=ax.transAxes, ha='right', fontsize=5.8)
fig = plt.figure(figsize=(7.4, 5.4))
gs = fig.add_gridspec(2, 4, hspace=0.55, wspace=0.75)
Sg = dcenter(np.load(f'{C}/T6_generic_similarity.npy'), W).ravel()
ax = fig.add_subplot(gs[0, 0]); panel(ax, 'a', x=-0.4)
sc(ax, Sg, y, 'Transcriptomic similarity\n(double-centred)', 'Interaction term', f"ρ = {S['T6']['generic_similarity_rho']:.2f}")
ax.legend(frameon=False, fontsize=5, loc='upper right', handletextpad=0.1)
P = np.load(f'{C}/T4_pcdh_similarity.npy'); Pd = dcenter(np.nan_to_num(P, nan=np.nanmean(P)), W).ravel()
ax = fig.add_subplot(gs[0, 1]); panel(ax, 'b', x=-0.4)
sc(ax, Pd, y, 'Clustered-Pcdh similarity\n(double-centred)', 'Interaction term',
   f"ρ = {S['T4_pcdh']['rho']:.2f} (P = {S['T4_pcdh']['p_perm']:.3f})\npartial | transcriptome = {S['T6']['pcdh_partial_given_generic'][0]:.2f}", top=True)
ax = fig.add_subplot(gs[0, 2]); panel(ax, 'c', x=-0.4)
mf = dcenter(M('multi_frac'), W).ravel()
sc(ax, y, mf, 'Interaction term', 'Multisynaptic fraction\n(double-centred)', f"ρ = {stats.spearmanr(y, mf)[0]:.2f}")
ax = fig.add_subplot(gs[0, 3]); panel(ax, 'd', x=-0.4)
ms = dcenter(M('mean_log_size'), W).ravel()
sc(ax, y, ms, 'Interaction term', 'Mean log$_{10}$ cleft size\n(double-centred)', f"ρ = {stats.spearmanr(y, ms)[0]:.2f}")

# e: robustness across analysis choices
ax = fig.add_subplot(gs[1, :]); panel(ax, 'e', x=-0.05)
runs = [('main', 'Main analysis')] + [(p.split('code_sens_')[1], {'patchseq': 'Patch-seq expression (interneurons)', 'mapNGC': 'NGC ↔ Sncg mapping',
         'map6CT': '6P-CT ↔ L6b mapping', 'reldepth': 'Relative-depth geometric null', 'binary': 'Binary connections', 'strictrules': 'Absolute splice rules only'}.get(p.split('code_sens_')[1], p))
        for p in sorted(glob.glob(f'{R}/code_sens_*')) if os.path.exists(f'{p}/summary.json')]
cols = [('T2', 'pair_blind', 'CV ρ\ngene-level'), ('T2', 'pair_iso', 'CV ρ\nisoform'), ('T2', 'random_genes_median', 'CV ρ random\ngenes (median)'),
        ('T2', 'p_random_genes', 'P vs random\ngenes'), ('T3', 'delta_cv_rho', 'Δρ isoform'), ('T3', 'p_psi_perm', 'P PSI-perm'),
        ('T4_pcdh', 'rho', 'Pcdh ρ'), ('T6', 'pcdh_partial_given_generic', 'Pcdh partial ρ'), ('T7_noise_ceiling', 'spearman_brown', 'Noise ceiling')]
tab = []
for tag, nm in runs:
    d = json.load(open(f'{R}/code/summary.json' if tag == 'main' else f'{R}/code_sens_{tag}/summary.json'))
    row = []
    for a, b, _ in cols:
        v = d.get(a, {}).get(b, np.nan)
        row.append(v[0] if isinstance(v, list) else v)
    tab.append(row)
T = np.array(tab, float)
ax.imshow(np.zeros_like(T), cmap='Greys', vmin=0, vmax=1, aspect='auto')
for i in range(T.shape[0]):
    for j in range(T.shape[1]):
        ax.text(j, i, f'{T[i, j]:.2f}', ha='center', va='center', fontsize=6, color=INK)
ax.set_xticks(range(len(cols))); ax.set_xticklabels([c[2] for c in cols], fontsize=5.6); ax.xaxis.tick_top()
ax.set_yticks(range(len(runs))); ax.set_yticklabels([r[1] for r in runs], fontsize=6)
ax.set_xticks(np.arange(-0.5, len(cols)), minor=True); ax.set_yticks(np.arange(-0.5, len(runs)), minor=True)
ax.grid(which='minor', color=GRID, lw=0.6); ax.tick_params(which='both', length=0); ax.spines[:].set_visible(False)
pd.DataFrame(T, index=[r[1] for r in runs], columns=[c[2].replace('\n', ' ') for c in cols]).to_csv(f'{R}/robustness_table.csv')
save(fig, f'{FD}/Figure4'); print('ok', len(runs))
