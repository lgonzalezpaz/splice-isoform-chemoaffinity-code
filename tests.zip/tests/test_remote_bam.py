"""Validate remote range-based extraction against pysam on a fully downloaded, locally indexed BAM."""
import os as _os, sys as _sys
_sys.path.insert(0, _os.path.dirname(_os.path.abspath(__file__)) if 'src' in __file__ else _os.path.join(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))), 'src'))
from paths import ROOT, DATA, RES
import sys, time, collections, json
sys.path.insert(0, f'{ROOT}/src')
import pysam
from remote_bam import RemoteBAM, blocks_and_junctions
from chrom_map import UCSC2REFSEQ
URL, LOCAL = sys.argv[1], sys.argv[2]
ann = json.load(open(f'{ROOT}/data_ref/adhesion_annotation_vM25.json'))
loci = [(g, ann['genes'][g]) for g in ['Nrxn1', 'Nrxn3', 'Nlgn1', 'Cadm1', 'Pcdhga1', 'Ptprd']]
rb = RemoteBAM(URL); lb = pysam.AlignmentFile(LOCAL)
allok = True
for g, v in loci:
    ch = UCSC2REFSEQ[v['chrom']]
    t = time.time(); jr = collections.Counter(); nr = 0
    for pos1, cig, flag, qn in rb.fetch(ch, v['start'], v['end']):
        nr += 1
        for j in blocks_and_junctions(pos1, cig)[1]: jr[j] += 1
    tr = time.time() - t
    jl = collections.Counter(); nl = 0
    for r in lb.fetch(ch, v['start'] - 1, v['end']):
        if r.mapping_quality != 255 or r.reference_start < v['start'] - 1 or r.reference_start > v['end'] - 1: continue
        nl += 1
        pos = r.reference_start + 1
        for op, ln in r.cigartuples:
            if op in (0, 7, 8, 2): pos += ln
            elif op == 3: jl[(pos, pos + ln - 1)] += 1; pos += ln
    ok = (nr == nl and jr == jl); allok &= ok
    print(f"{g}: remote reads={nr} local reads={nl} junctions identical={jr == jl} n_junc={sum(jl.values())} time={tr:.1f}s")
print('requests', rb.nreq, 'MB', round(rb.nbytes / 1e6, 2), 'ALL_OK', allok)
